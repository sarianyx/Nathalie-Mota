# WordPress MySQL database migration
#
# Generated: Wednesday 7. August 2024 12:31 UTC
# Hostname: localhost
# Database: `mota`
# URL: //localhost/mota
# Path: C:\\xampp\\htdocs\\mota
# Tables: wp_actionscheduler_actions, wp_actionscheduler_claims, wp_actionscheduler_groups, wp_actionscheduler_logs, wp_commentmeta, wp_comments, wp_ewwwio_images, wp_ewwwio_queue, wp_links, wp_options, wp_postmeta, wp_posts, wp_smush_dir_images, wp_term_relationships, wp_term_taxonomy, wp_termmeta, wp_terms, wp_usermeta, wp_users
# Table Prefix: wp_
# Post Types: revision, acf-field, acf-field-group, attachment, nav_menu_item, page, photo, post, wp_navigation, wp_template, wpcf7_contact_form, wpcode
# Protocol: https
# Multisite: false
# Subsite Export: false
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_actionscheduler_actions`
#

DROP TABLE IF EXISTS `wp_actionscheduler_actions`;


#
# Table structure of table `wp_actionscheduler_actions`
#

CREATE TABLE `wp_actionscheduler_actions` (
  `action_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `hook` varchar(191) NOT NULL,
  `status` varchar(20) NOT NULL,
  `scheduled_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `scheduled_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  `priority` tinyint(3) unsigned NOT NULL DEFAULT 10,
  `args` varchar(191) DEFAULT NULL,
  `schedule` longtext DEFAULT NULL,
  `group_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `attempts` int(11) NOT NULL DEFAULT 0,
  `last_attempt_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `last_attempt_local` datetime DEFAULT '0000-00-00 00:00:00',
  `claim_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `extended_args` varchar(8000) DEFAULT NULL,
  PRIMARY KEY (`action_id`),
  KEY `hook_status_scheduled_date_gmt` (`hook`(163),`status`,`scheduled_date_gmt`),
  KEY `status_scheduled_date_gmt` (`status`,`scheduled_date_gmt`),
  KEY `scheduled_date_gmt` (`scheduled_date_gmt`),
  KEY `args` (`args`),
  KEY `group_id` (`group_id`),
  KEY `last_attempt_gmt` (`last_attempt_gmt`),
  KEY `claim_id_status_scheduled_date_gmt` (`claim_id`,`status`,`scheduled_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_actions`
#
INSERT INTO `wp_actionscheduler_actions` ( `action_id`, `hook`, `status`, `scheduled_date_gmt`, `scheduled_date_local`, `priority`, `args`, `schedule`, `group_id`, `attempts`, `last_attempt_gmt`, `last_attempt_local`, `claim_id`, `extended_args`) VALUES
(93, 'action_scheduler/migration_hook', 'pending', '2024-08-07 10:18:05', '2024-08-07 12:18:05', 10, '[]', 'O:30:"ActionScheduler_SimpleSchedule":4:{s:22:"\0*\0scheduled_timestamp";i:1723025885;s:41:"\0ActionScheduler_SimpleSchedule\0timestamp";i:1723025885;s:19:"scheduled_timestamp";i:1723025885;s:9:"timestamp";i:1723025885;}', 1, 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00', 0, NULL) ;

#
# End of data contents of table `wp_actionscheduler_actions`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_claims`
#

DROP TABLE IF EXISTS `wp_actionscheduler_claims`;


#
# Table structure of table `wp_actionscheduler_claims`
#

CREATE TABLE `wp_actionscheduler_claims` (
  `claim_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `date_created_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`claim_id`),
  KEY `date_created_gmt` (`date_created_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_claims`
#

#
# End of data contents of table `wp_actionscheduler_claims`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_groups`
#

DROP TABLE IF EXISTS `wp_actionscheduler_groups`;


#
# Table structure of table `wp_actionscheduler_groups`
#

CREATE TABLE `wp_actionscheduler_groups` (
  `group_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `slug` (`slug`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_groups`
#
INSERT INTO `wp_actionscheduler_groups` ( `group_id`, `slug`) VALUES
(1, 'action-scheduler-migration') ;

#
# End of data contents of table `wp_actionscheduler_groups`
# --------------------------------------------------------



#
# Delete any existing table `wp_actionscheduler_logs`
#

DROP TABLE IF EXISTS `wp_actionscheduler_logs`;


#
# Table structure of table `wp_actionscheduler_logs`
#

CREATE TABLE `wp_actionscheduler_logs` (
  `log_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `action_id` bigint(20) unsigned NOT NULL,
  `message` text NOT NULL,
  `log_date_gmt` datetime DEFAULT '0000-00-00 00:00:00',
  `log_date_local` datetime DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`log_id`),
  KEY `action_id` (`action_id`),
  KEY `log_date_gmt` (`log_date_gmt`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_actionscheduler_logs`
#
INSERT INTO `wp_actionscheduler_logs` ( `log_id`, `action_id`, `message`, `log_date_gmt`, `log_date_local`) VALUES
(1, 93, 'action created', '2024-08-07 10:17:06', '2024-08-07 12:17:06') ;

#
# End of data contents of table `wp_actionscheduler_logs`
# --------------------------------------------------------



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT 0,
  `comment_author` tinytext NOT NULL,
  `comment_author_email` varchar(100) NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT 0,
  `comment_approved` varchar(20) NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) NOT NULL DEFAULT '',
  `comment_type` varchar(20) NOT NULL DEFAULT 'comment',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Un commentateur ou commentatrice WordPress', 'wapuu@wordpress.example', 'https://fr.wordpress.org/', '', '2024-06-26 11:23:11', '2024-06-26 09:23:11', 'Bonjour, ceci est un commentaire.\nPour débuter avec la modération, la modification et la suppression de commentaires, veuillez visiter l’écran des Commentaires dans le Tableau de bord.\nLes avatars des personnes qui commentent arrivent depuis <a href="https://fr.gravatar.com/">Gravatar</a>.', 0, '1', '', 'comment', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_ewwwio_images`
#

DROP TABLE IF EXISTS `wp_ewwwio_images`;


#
# Table structure of table `wp_ewwwio_images`
#

CREATE TABLE `wp_ewwwio_images` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` bigint(20) unsigned DEFAULT NULL,
  `gallery` varchar(10) DEFAULT NULL,
  `resize` varchar(75) DEFAULT NULL,
  `path` text NOT NULL,
  `converted` text NOT NULL,
  `image_size` int(10) unsigned DEFAULT NULL,
  `orig_size` int(10) unsigned DEFAULT NULL,
  `backup` varchar(100) DEFAULT NULL,
  `retrieve` varchar(100) DEFAULT NULL,
  `level` int(10) unsigned DEFAULT NULL,
  `resized_width` smallint(5) unsigned DEFAULT NULL,
  `resized_height` smallint(5) unsigned DEFAULT NULL,
  `resize_error` tinyint(3) unsigned DEFAULT NULL,
  `webp_size` int(10) unsigned DEFAULT NULL,
  `webp_error` tinyint(3) unsigned DEFAULT NULL,
  `pending` tinyint(4) NOT NULL DEFAULT 0,
  `updates` int(10) unsigned DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `trace` blob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `path` (`path`(191)),
  KEY `attachment_info` (`gallery`(3),`attachment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_ewwwio_images`
#
INSERT INTO `wp_ewwwio_images` ( `id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `image_size`, `orig_size`, `backup`, `retrieve`, `level`, `resized_width`, `resized_height`, `resize_error`, `webp_size`, `webp_error`, `pending`, `updates`, `updated`, `trace`) VALUES
(1, 53, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-scaled.jpeg', '', 785980, 1436222, '', NULL, 10, 1920, 1920, 0, 589908, 0, 0, 1, '2024-08-07 11:53:32', NULL),
(2, 53, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-300x225.jpeg', '', 27080, 29181, '', NULL, 10, NULL, NULL, NULL, 22560, 0, 0, 1, '2024-08-07 11:53:33', NULL),
(3, 53, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-1024x768.jpeg', '', 274903, 296912, '', NULL, 10, NULL, NULL, NULL, 221950, 0, 0, 1, '2024-08-07 11:53:34', NULL),
(4, 53, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-150x150.jpeg', '', 9640, 10389, '', NULL, 10, NULL, NULL, NULL, 8122, 0, 0, 1, '2024-08-07 11:53:34', NULL),
(5, 53, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-768x576.jpeg', '', 160205, 173232, '', NULL, 10, NULL, NULL, NULL, 132808, 0, 0, 1, '2024-08-07 11:53:35', NULL),
(6, 53, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-1536x1152.jpeg', '', 570623, 614953, '', NULL, 10, NULL, NULL, NULL, 450188, 0, 0, 1, '2024-08-07 11:53:36', NULL),
(7, 53, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-10-2048x1536.jpeg', '', 932555, 1002899, '', NULL, 10, NULL, NULL, NULL, 706172, 0, 0, 1, '2024-08-07 11:53:39', NULL),
(8, 61, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-scaled.jpeg', '', 149846, 259636, '', NULL, 10, 1920, 1920, 0, 55434, 0, 0, 1, '2024-08-07 11:54:05', NULL),
(9, 61, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-200x300.jpeg', '', 9992, 10365, '', NULL, 10, NULL, NULL, NULL, 5480, 0, 0, 1, '2024-08-07 11:54:06', NULL),
(10, 61, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-683x1024.jpeg', '', 58782, 60455, '', NULL, 10, NULL, NULL, NULL, 25126, 0, 0, 1, '2024-08-07 11:54:06', NULL),
(11, 61, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-150x150.jpeg', '', 4720, 5084, '', NULL, 10, NULL, NULL, NULL, 2660, 0, 0, 1, '2024-08-07 11:54:07', NULL),
(12, 61, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-768x1152.jpeg', '', 69066, 71101, '', NULL, 10, NULL, NULL, NULL, 29670, 0, 0, 1, '2024-08-07 11:54:07', NULL),
(13, 61, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-1024x1536.jpeg', '', 105813, 109909, '', NULL, 10, NULL, NULL, NULL, 42440, 0, 0, 1, '2024-08-07 11:54:08', NULL),
(14, 61, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-3-1365x2048.jpeg', '', 166283, 175163, '', NULL, 10, NULL, NULL, NULL, 62660, 0, 0, 1, '2024-08-07 11:54:09', NULL),
(15, 60, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-scaled.jpeg', '', 551066, 1004793, '', NULL, 10, 1920, 1920, 0, 369154, 0, 0, 1, '2024-08-07 11:54:12', NULL),
(16, 60, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-300x181.jpeg', '', 21364, 23206, '', NULL, 10, NULL, NULL, NULL, 16784, 0, 0, 1, '2024-08-07 11:54:13', NULL),
(17, 60, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-1024x617.jpeg', '', 200303, 216804, '', NULL, 10, NULL, NULL, NULL, 148622, 0, 0, 1, '2024-08-07 11:54:13', NULL),
(18, 60, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-150x150.jpeg', '', 10553, 11532, '', NULL, 10, NULL, NULL, NULL, 8740, 0, 0, 1, '2024-08-07 11:54:14', NULL),
(19, 60, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-768x463.jpeg', '', 119786, 130007, '', NULL, 10, NULL, NULL, NULL, 91916, 0, 0, 1, '2024-08-07 11:54:14', NULL),
(20, 60, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-1536x926.jpeg', '', 401736, 433661, '', NULL, 10, NULL, NULL, NULL, 282944, 0, 0, 1, '2024-08-07 11:54:16', NULL),
(21, 60, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-2-2048x1235.jpeg', '', 651492, 700802, '', NULL, 10, NULL, NULL, NULL, 444034, 0, 0, 1, '2024-08-07 11:54:18', NULL),
(22, 58, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-scaled.jpeg', '', 223228, 384952, '', NULL, 10, 1920, 1920, 0, 89128, 0, 0, 1, '2024-08-07 11:54:22', NULL),
(23, 58, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-300x200.jpeg', '', 14686, 15679, '', NULL, 10, NULL, NULL, NULL, 9444, 0, 0, 1, '2024-08-07 11:54:25', NULL),
(24, 58, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-1024x683.jpeg', '', 86728, 89350, '', NULL, 10, NULL, NULL, NULL, 41294, 0, 0, 1, '2024-08-07 11:54:25', NULL),
(25, 58, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-150x150.jpeg', '', 7332, 7805, '', NULL, 10, NULL, NULL, NULL, 4902, 0, 0, 1, '2024-08-07 11:54:26', NULL),
(26, 58, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-768x512.jpeg', '', 56932, 59088, '', NULL, 10, NULL, NULL, NULL, 28970, 0, 0, 1, '2024-08-07 11:54:26', NULL),
(27, 58, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-1536x1024.jpeg', '', 158178, 162236, '', NULL, 10, NULL, NULL, NULL, 68182, 0, 0, 1, '2024-08-07 11:54:27', NULL),
(28, 58, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-0-2048x1365.jpeg', '', 250852, 258570, '', NULL, 10, NULL, NULL, NULL, 99596, 0, 0, 1, '2024-08-07 11:54:29', NULL),
(29, 59, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-scaled.jpeg', '', 366385, 639679, '', NULL, 10, 1920, 1920, 0, 177942, 0, 0, 1, '2024-08-07 11:54:33', NULL),
(30, 59, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-300x200.jpeg', '', 19299, 20691, '', NULL, 10, NULL, NULL, NULL, 13956, 0, 0, 1, '2024-08-07 11:54:33', NULL),
(31, 59, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-1024x683.jpeg', '', 138484, 144465, '', NULL, 10, NULL, NULL, NULL, 82594, 0, 0, 1, '2024-08-07 11:54:34', NULL),
(32, 59, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-150x150.jpeg', '', 8613, 9081, '', NULL, 10, NULL, NULL, NULL, 6158, 0, 0, 1, '2024-08-07 11:54:34', NULL),
(33, 59, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-768x512.jpeg', '', 87873, 92386, '', NULL, 10, NULL, NULL, NULL, 54920, 0, 0, 1, '2024-08-07 11:54:35', NULL),
(34, 59, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-1536x1024.jpeg', '', 263799, 273409, '', NULL, 10, NULL, NULL, NULL, 140616, 0, 0, 1, '2024-08-07 11:54:36', NULL),
(35, 59, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-1-2048x1365.jpeg', '', 421371, 436388, '', NULL, 10, NULL, NULL, NULL, 206988, 0, 0, 1, '2024-08-07 11:54:38', NULL),
(36, 57, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-scaled.jpeg', '', 405597, 685796, '', NULL, 10, 1920, 1920, 0, 222308, 0, 0, 1, '2024-08-07 11:54:42', NULL),
(37, 57, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-200x300.jpeg', '', 19794, 21406, '', NULL, 10, NULL, NULL, NULL, 15264, 0, 0, 1, '2024-08-07 11:54:42', NULL),
(38, 57, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-684x1024.jpeg', '', 153808, 162353, '', NULL, 10, NULL, NULL, NULL, 98388, 0, 0, 1, '2024-08-07 11:54:43', NULL),
(39, 57, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-150x150.jpeg', '', 8687, 9111, '', NULL, 10, NULL, NULL, NULL, 6392, 0, 0, 1, '2024-08-07 11:54:44', NULL),
(40, 57, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-768x1150.jpeg', '', 185256, 194862, '', NULL, 10, NULL, NULL, NULL, 116380, 0, 0, 1, '2024-08-07 11:54:47', NULL),
(41, 57, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-1025x1536.jpeg', '', 296427, 310272, '', NULL, 10, NULL, NULL, NULL, 175698, 0, 0, 1, '2024-08-07 11:54:48', NULL),
(42, 57, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-15-1367x2048.jpeg', '', 465501, 484463, '', NULL, 10, NULL, NULL, NULL, 260410, 0, 0, 1, '2024-08-07 11:54:50', NULL),
(43, 56, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-scaled.jpeg', '', 274509, 498092, '', NULL, 10, 1920, 1920, 0, 152780, 0, 0, 1, '2024-08-07 11:54:53', NULL),
(44, 56, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-200x300.jpeg', '', 11670, 12286, '', NULL, 10, NULL, NULL, NULL, 7148, 0, 0, 1, '2024-08-07 11:54:54', NULL),
(45, 56, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-683x1024.jpeg', '', 97840, 103250, '', NULL, 10, NULL, NULL, NULL, 59330, 0, 0, 1, '2024-08-07 11:54:54', NULL),
(46, 56, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-150x150.jpeg', '', 5583, 5957, '', NULL, 10, NULL, NULL, NULL, 3594, 0, 0, 1, '2024-08-07 11:54:55', NULL),
(47, 56, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-768x1152.jpeg', '', 119233, 125978, '', NULL, 10, NULL, NULL, NULL, 72148, 0, 0, 1, '2024-08-07 11:54:55', NULL),
(48, 56, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-1024x1536.jpeg', '', 195817, 206879, '', NULL, 10, NULL, NULL, NULL, 116522, 0, 0, 1, '2024-08-07 11:54:56', NULL),
(49, 56, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-14-1365x2048.jpeg', '', 321282, 339652, '', NULL, 10, NULL, NULL, NULL, 187162, 0, 0, 1, '2024-08-07 11:54:58', NULL),
(50, 55, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-scaled.jpeg', '', 171816, 289836, '', NULL, 10, 1920, 1920, 0, 66786, 0, 0, 1, '2024-08-07 11:55:02', NULL),
(51, 55, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-200x300.jpeg', '', 10566, 11006, '', NULL, 10, NULL, NULL, NULL, 5968, 0, 0, 1, '2024-08-07 11:55:02', NULL),
(52, 55, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-683x1024.jpeg', '', 67140, 69432, '', NULL, 10, NULL, NULL, NULL, 30706, 0, 0, 1, '2024-08-07 11:55:03', NULL),
(53, 55, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-150x150.jpeg', '', 5724, 6089, '', NULL, 10, NULL, NULL, NULL, 3516, 0, 0, 1, '2024-08-07 11:55:03', NULL),
(54, 55, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-768x1152.jpeg', '', 79879, 82529, '', NULL, 10, NULL, NULL, NULL, 35358, 0, 0, 1, '2024-08-07 11:55:04', NULL),
(55, 55, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-1024x1536.jpeg', '', 122912, 127418, '', NULL, 10, NULL, NULL, NULL, 50932, 0, 0, 1, '2024-08-07 11:55:06', NULL),
(56, 55, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-13-1365x2048.jpeg', '', 191523, 200278, '', NULL, 10, NULL, NULL, NULL, 74544, 0, 0, 1, '2024-08-07 11:55:08', NULL),
(57, 54, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-scaled.jpeg', '', 317437, 517335, '', NULL, 10, 1920, 1920, 0, 150346, 0, 0, 1, '2024-08-07 11:55:12', NULL),
(58, 54, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-300x200.jpeg', '', 19079, 20524, '', NULL, 10, NULL, NULL, NULL, 14282, 0, 0, 1, '2024-08-07 11:55:13', NULL),
(59, 54, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-1024x683.jpeg', '', 126466, 132275, '', NULL, 10, NULL, NULL, NULL, 72758, 0, 0, 1, '2024-08-07 11:55:14', NULL),
(60, 54, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-150x150.jpeg', '', 9639, 10134, '', NULL, 10, NULL, NULL, NULL, 7358, 0, 0, 1, '2024-08-07 11:55:14', NULL),
(61, 54, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-768x512.jpeg', '', 81539, 85955, '', NULL, 10, NULL, NULL, NULL, 50438, 0, 0, 1, '2024-08-07 11:55:15', NULL),
(62, 54, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-1536x1024.jpeg', '', 230351, 238906, '', NULL, 10, NULL, NULL, NULL, 119590, 0, 0, 1, '2024-08-07 11:55:16', NULL),
(63, 54, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-12-2048x1365.jpeg', '', 355826, 367406, '', NULL, 10, NULL, NULL, NULL, 167328, 0, 0, 1, '2024-08-07 11:55:17', NULL),
(64, 52, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-scaled.jpeg', '', 345581, 658992, '', NULL, 10, 1920, 1920, 0, 153462, 0, 0, 1, '2024-08-07 11:55:21', NULL),
(65, 52, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-300x200.jpeg', '', 14940, 15837, '', NULL, 10, NULL, NULL, NULL, 9514, 0, 0, 1, '2024-08-07 11:55:22', NULL),
(66, 52, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-1024x683.jpeg', '', 117812, 122201, '', NULL, 10, NULL, NULL, NULL, 61492, 0, 0, 1, '2024-08-07 11:55:23', NULL),
(67, 52, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-150x150.jpeg', '', 7473, 7887, '', NULL, 10, NULL, NULL, NULL, 5108, 0, 0, 1, '2024-08-07 11:55:23', NULL),
(68, 52, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-768x512.jpeg', '', 71411, 74356, '', NULL, 10, NULL, NULL, NULL, 39824, 0, 0, 1, '2024-08-07 11:55:23', NULL),
(69, 52, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-1536x1024.jpeg', '', 239467, 249760, '', NULL, 10, NULL, NULL, NULL, 116764, 0, 0, 1, '2024-08-07 11:55:25', NULL),
(70, 52, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-9-2048x1365.jpeg', '', 409691, 429918, '', NULL, 10, NULL, NULL, NULL, 192166, 0, 0, 1, '2024-08-07 11:55:26', NULL),
(71, 51, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-scaled.jpeg', '', 277623, 452277, '', NULL, 10, 1920, 1920, 0, 135106, 0, 0, 1, '2024-08-07 11:55:34', NULL),
(72, 51, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-200x300.jpeg', '', 17497, 18792, '', NULL, 10, NULL, NULL, NULL, 12236, 0, 0, 1, '2024-08-07 11:55:34', NULL),
(73, 51, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-684x1024.jpeg', '', 110018, 113945, '', NULL, 10, NULL, NULL, NULL, 62990, 0, 0, 1, '2024-08-07 11:55:35', NULL),
(74, 51, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-150x150.jpeg', '', 9130, 9608, '', NULL, 10, NULL, NULL, NULL, 6478, 0, 0, 1, '2024-08-07 11:55:36', NULL),
(75, 51, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-768x1150.jpeg', '', 130484, 134899, '', NULL, 10, NULL, NULL, NULL, 72956, 0, 0, 1, '2024-08-07 11:55:36', NULL),
(76, 51, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-1025x1536.jpeg', '', 201564, 207201, '', NULL, 10, NULL, NULL, NULL, 104914, 0, 0, 1, '2024-08-07 11:55:37', NULL),
(77, 51, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-8-1367x2048.jpeg', '', 311207, 319495, '', NULL, 10, NULL, NULL, NULL, 153702, 0, 0, 1, '2024-08-07 11:55:39', NULL),
(78, 50, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-scaled.jpeg', '', 241524, 395977, '', NULL, 10, 1920, 1920, 0, 95652, 0, 0, 1, '2024-08-07 11:55:43', NULL),
(79, 50, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-300x200.jpeg', '', 14142, 14818, '', NULL, 10, NULL, NULL, NULL, 8904, 0, 0, 1, '2024-08-07 11:55:43', NULL),
(80, 50, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-1024x683.jpeg', '', 93348, 95336, '', NULL, 10, NULL, NULL, NULL, 45576, 0, 0, 1, '2024-08-07 11:55:44', NULL),
(81, 50, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-150x150.jpeg', '', 6471, 6867, '', NULL, 10, NULL, NULL, NULL, 4222, 0, 0, 1, '2024-08-07 11:55:44', NULL),
(82, 50, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-768x512.jpeg', '', 60109, 61792, '', NULL, 10, NULL, NULL, NULL, 31736, 0, 0, 1, '2024-08-07 11:55:45', NULL),
(83, 50, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-1536x1024.jpeg', '', 172849, 175756, '', NULL, 10, NULL, NULL, NULL, 74316, 0, 0, 1, '2024-08-07 11:55:46', NULL),
(84, 50, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-7-2048x1365.jpeg', '', 270591, 276299, '', NULL, 10, NULL, NULL, NULL, 106542, 0, 0, 1, '2024-08-07 11:55:48', NULL),
(85, 49, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-scaled.jpeg', '', 383266, 770392, '', NULL, 10, 1920, 1920, 0, 156496, 0, 0, 1, '2024-08-07 11:55:52', NULL),
(86, 49, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-300x240.jpeg', '', 15227, 16035, '', NULL, 10, NULL, NULL, NULL, 8876, 0, 0, 1, '2024-08-07 11:55:54', NULL),
(87, 49, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-1024x819.jpeg', '', 119012, 125120, '', NULL, 10, NULL, NULL, NULL, 53810, 0, 0, 1, '2024-08-07 11:55:55', NULL),
(88, 49, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-150x150.jpeg', '', 6182, 6585, '', NULL, 10, NULL, NULL, NULL, 3702, 0, 0, 1, '2024-08-07 11:55:55', NULL),
(89, 49, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-768x614.jpeg', '', 70991, 74097, '', NULL, 10, NULL, NULL, NULL, 33936, 0, 0, 1, '2024-08-07 11:55:56', NULL),
(90, 49, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-1536x1229.jpeg', '', 257672, 273871, '', NULL, 10, NULL, NULL, NULL, 108982, 0, 0, 1, '2024-08-07 11:55:57', NULL),
(91, 49, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-6-2048x1638.jpeg', '', 459400, 490188, '', NULL, 10, NULL, NULL, NULL, 193182, 0, 0, 1, '2024-08-07 11:56:00', NULL),
(92, 48, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-scaled.jpeg', '', 442954, 860691, '', NULL, 10, 1920, 1920, 0, 244560, 0, 0, 1, '2024-08-07 11:56:04', NULL),
(93, 48, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-200x300.jpeg', '', 19961, 21528, '', NULL, 10, NULL, NULL, NULL, 15536, 0, 0, 1, '2024-08-07 11:56:04', NULL),
(94, 48, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-683x1024.jpeg', '', 157234, 166621, '', NULL, 10, NULL, NULL, NULL, 102214, 0, 0, 1, '2024-08-07 11:56:05', NULL),
(95, 48, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-150x150.jpeg', '', 8796, 9225, '', NULL, 10, NULL, NULL, NULL, 6482, 0, 0, 1, '2024-08-07 11:56:05', NULL),
(96, 48, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-768x1152.jpeg', '', 190989, 202311, '', NULL, 10, NULL, NULL, NULL, 120408, 0, 0, 1, '2024-08-07 11:56:06', NULL),
(97, 48, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-1024x1536.jpeg', '', 314409, 333265, '', NULL, 10, NULL, NULL, NULL, 188842, 0, 0, 1, '2024-08-07 11:56:07', NULL),
(98, 48, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-5-1365x2048.jpeg', '', 530969, 563803, '', NULL, 10, NULL, NULL, NULL, 308086, 0, 0, 1, '2024-08-07 11:56:09', NULL),
(99, 47, 'media', 'full', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-scaled.jpeg', '', 405064, 694071, '', NULL, 10, 1920, 1920, 0, 223648, 0, 0, 1, '2024-08-07 11:56:13', NULL),
(100, 47, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-200x300.jpeg', '', 19120, 20372, '', NULL, 10, NULL, NULL, NULL, 14330, 0, 0, 1, '2024-08-07 11:56:14', NULL) ;
INSERT INTO `wp_ewwwio_images` ( `id`, `attachment_id`, `gallery`, `resize`, `path`, `converted`, `image_size`, `orig_size`, `backup`, `retrieve`, `level`, `resized_width`, `resized_height`, `resize_error`, `webp_size`, `webp_error`, `pending`, `updates`, `updated`, `trace`) VALUES
(101, 47, 'media', 'large', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-683x1024.jpeg', '', 154007, 161713, '', NULL, 10, NULL, NULL, NULL, 99236, 0, 0, 1, '2024-08-07 11:56:16', NULL),
(102, 47, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-150x150.jpeg', '', 8301, 8723, '', NULL, 10, NULL, NULL, NULL, 5878, 0, 0, 1, '2024-08-07 11:56:17', NULL),
(103, 47, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-768x1152.jpeg', '', 185149, 194213, '', NULL, 10, NULL, NULL, NULL, 116098, 0, 0, 1, '2024-08-07 11:56:18', NULL),
(104, 47, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-1024x1536.jpeg', '', 293652, 306793, '', NULL, 10, NULL, NULL, NULL, 174168, 0, 0, 1, '2024-08-07 11:56:19', NULL),
(105, 47, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/07/nathalie-4-1365x2048.jpeg', '', 465707, 485783, '', NULL, 10, NULL, NULL, NULL, 260702, 0, 0, 1, '2024-08-07 11:56:20', NULL),
(106, 5, 'media', 'full', 'ABSPATHwp-content/uploads/2024/06/Logo.png', '', 2157, 3534, '', NULL, 10, NULL, NULL, NULL, 1654, 0, 0, 1, '2024-08-07 11:56:22', NULL),
(107, 5, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/06/Logo-300x19.png', '', 2171, 2619, '', NULL, 10, NULL, NULL, NULL, 1426, 0, 0, 1, '2024-08-07 11:56:22', NULL),
(108, 5, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/06/Logo-150x44.png', '', 317, 511, '', NULL, 10, NULL, NULL, NULL, 178, 0, 0, 1, '2024-08-07 11:56:23', NULL),
(109, 8, 'media', 'full', 'ABSPATHwp-content/uploads/2024/06/nathalie-11-scaled.jpeg', '', 223881, 370835, '', NULL, 10, 1920, 1920, 0, 89000, 0, 0, 1, '2024-08-07 11:56:27', NULL),
(110, 8, 'media', 'medium', 'ABSPATHwp-content/uploads/2024/06/nathalie-11-300x200.jpeg', '', 15336, 16186, '', NULL, 10, NULL, NULL, NULL, 9964, 0, 0, 1, '2024-08-07 11:56:27', NULL),
(111, 8, 'media', 'large', 'ABSPATHwp-content/uploads/2024/06/nathalie-11-1024x684.jpeg', '', 89733, 92326, '', NULL, 10, NULL, NULL, NULL, 42638, 0, 0, 1, '2024-08-07 11:56:28', NULL),
(112, 8, 'media', 'thumbnail', 'ABSPATHwp-content/uploads/2024/06/nathalie-11-150x150.jpeg', '', 7628, 8057, '', NULL, 10, NULL, NULL, NULL, 5240, 0, 0, 1, '2024-08-07 11:56:28', NULL),
(113, 8, 'media', 'medium_large', 'ABSPATHwp-content/uploads/2024/06/nathalie-11-768x513.jpeg', '', 59680, 61729, '', NULL, 10, NULL, NULL, NULL, 31024, 0, 0, 1, '2024-08-07 11:56:28', NULL),
(114, 8, 'media', '1536x1536', 'ABSPATHwp-content/uploads/2024/06/nathalie-11-1536x1025.jpeg', '', 160800, 165074, '', NULL, 10, NULL, NULL, NULL, 69608, 0, 0, 1, '2024-08-07 11:56:29', NULL),
(115, 8, 'media', '2048x2048', 'ABSPATHwp-content/uploads/2024/06/nathalie-11-2048x1367.jpeg', '', 248616, 256460, '', NULL, 10, NULL, NULL, NULL, 97610, 0, 0, 1, '2024-08-07 11:56:31', NULL),
(116, NULL, NULL, NULL, 'C:\\xampp\\htdocs\\mota\\wp-content/ewww/lazy/placeholder-690x44.png', '', 109, 133, '', NULL, 10, NULL, NULL, NULL, 40, 0, 0, 1, '2024-08-07 11:57:24', NULL),
(117, NULL, NULL, NULL, 'C:\\xampp\\htdocs\\mota\\wp-content/ewww/lazy/placeholder-684x1024.png', '', 194, 218, '', NULL, 10, NULL, NULL, NULL, 70, 0, 0, 1, '2024-08-07 11:57:24', NULL),
(118, NULL, NULL, NULL, 'C:\\xampp\\htdocs\\mota\\wp-content/ewww/lazy/placeholder-46x32.png', '', 96, 121, '', NULL, 10, NULL, NULL, NULL, 34, 0, 0, 1, '2024-08-07 11:57:24', NULL),
(119, NULL, NULL, NULL, 'C:\\xampp\\htdocs\\mota\\wp-content/ewww/lazy/placeholder-683x1024.png', '', 194, 218, '', NULL, 10, NULL, NULL, NULL, 70, 0, 0, 1, '2024-08-07 11:57:25', NULL),
(120, NULL, NULL, NULL, 'C:\\xampp\\htdocs\\mota\\wp-content/ewww/lazy/placeholder-1024x683.png', '', 193, 217, '', NULL, 10, NULL, NULL, NULL, 70, 0, 0, 1, '2024-08-07 11:57:25', NULL),
(121, NULL, NULL, NULL, 'C:\\xampp\\htdocs\\mota\\wp-content/ewww/lazy/placeholder-1024x768.png', '', 203, 227, '', NULL, 10, NULL, NULL, NULL, 74, 0, 0, 1, '2024-08-07 11:57:26', NULL),
(122, NULL, NULL, NULL, 'C:\\xampp\\htdocs\\mota\\wp-content/ewww/lazy/placeholder-1024x684.png', '', 192, 216, '', NULL, 10, NULL, NULL, NULL, 70, 0, 0, 1, '2024-08-07 11:57:26', NULL),
(123, NULL, NULL, NULL, 'C:\\xampp\\htdocs\\mota\\wp-content/ewww/lazy/placeholder-150x150.png', '', 111, 135, '', NULL, 10, NULL, NULL, NULL, 40, 0, 0, 1, '2024-08-07 12:00:48', NULL) ;

#
# End of data contents of table `wp_ewwwio_images`
# --------------------------------------------------------



#
# Delete any existing table `wp_ewwwio_queue`
#

DROP TABLE IF EXISTS `wp_ewwwio_queue`;


#
# Table structure of table `wp_ewwwio_queue`
#

CREATE TABLE `wp_ewwwio_queue` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `attachment_id` bigint(20) unsigned DEFAULT NULL,
  `gallery` varchar(20) DEFAULT NULL,
  `scanned` tinyint(4) NOT NULL DEFAULT 0,
  `new` tinyint(4) NOT NULL DEFAULT 0,
  `convert_once` tinyint(4) NOT NULL DEFAULT 0,
  `force_reopt` tinyint(4) NOT NULL DEFAULT 0,
  `force_smart` tinyint(4) NOT NULL DEFAULT 0,
  `webp_only` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `attachment_info` (`gallery`(3),`attachment_id`)
) ENGINE=InnoDB AUTO_INCREMENT=150 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;


#
# Data contents of table `wp_ewwwio_queue`
#

#
# End of data contents of table `wp_ewwwio_queue`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) NOT NULL DEFAULT '',
  `link_name` varchar(255) NOT NULL DEFAULT '',
  `link_image` varchar(255) NOT NULL DEFAULT '',
  `link_target` varchar(25) NOT NULL DEFAULT '',
  `link_description` varchar(255) NOT NULL DEFAULT '',
  `link_visible` varchar(20) NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT 1,
  `link_rating` int(11) NOT NULL DEFAULT 0,
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) NOT NULL DEFAULT '',
  `link_notes` mediumtext NOT NULL,
  `link_rss` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) NOT NULL DEFAULT '',
  `option_value` longtext NOT NULL,
  `autoload` varchar(20) NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`),
  KEY `autoload` (`autoload`)
) ENGINE=InnoDB AUTO_INCREMENT=1456 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'https://motaphoto.com', 'yes'),
(2, 'home', 'https://motaphoto.com', 'yes'),
(3, 'blogname', 'Nathalie Mota', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'erchluprev@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'G\\hi', 'yes'),
(25, 'links_updated_date_format', 'd F Y G\\hi', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '', 'yes'),
(29, 'rewrite_rules', '', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:6:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:43:"custom-post-type-ui/custom-post-type-ui.php";i:3;s:41:"wordpress-importer/wordpress-importer.php";i:4;s:31:"wp-migrate-db/wp-migrate-db.php";i:5;s:23:"wp-smushit/wp-smush.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'Mota-child', 'yes'),
(41, 'stylesheet', 'Mota-child', 'yes'),
(42, 'comment_registration', '0', 'yes'),
(43, 'html_type', 'text/html', 'yes'),
(44, 'use_trackback', '0', 'yes'),
(45, 'default_role', 'subscriber', 'yes'),
(46, 'db_version', '57155', 'yes'),
(47, 'uploads_use_yearmonth_folders', '1', 'yes'),
(48, 'upload_path', '', 'yes'),
(49, 'blog_public', '0', 'yes'),
(50, 'default_link_category', '2', 'yes'),
(51, 'show_on_front', 'page', 'yes'),
(52, 'tag_base', '', 'yes'),
(53, 'show_avatars', '1', 'yes'),
(54, 'avatar_rating', 'G', 'yes'),
(55, 'upload_url_path', '', 'yes'),
(56, 'thumbnail_size_w', '150', 'yes'),
(57, 'thumbnail_size_h', '150', 'yes'),
(58, 'thumbnail_crop', '1', 'yes'),
(59, 'medium_size_w', '300', 'yes'),
(60, 'medium_size_h', '300', 'yes'),
(61, 'avatar_default', 'mystery', 'yes'),
(62, 'large_size_w', '1024', 'yes'),
(63, 'large_size_h', '1024', 'yes'),
(64, 'image_default_link_type', 'none', 'yes'),
(65, 'image_default_size', '', 'yes'),
(66, 'image_default_align', '', 'yes'),
(67, 'close_comments_for_old_posts', '0', 'yes'),
(68, 'close_comments_days_old', '14', 'yes'),
(69, 'thread_comments', '1', 'yes'),
(70, 'thread_comments_depth', '5', 'yes'),
(71, 'page_comments', '0', 'yes'),
(72, 'comments_per_page', '50', 'yes'),
(73, 'default_comments_page', 'newest', 'yes'),
(74, 'comment_order', 'asc', 'yes'),
(75, 'sticky_posts', 'a:0:{}', 'yes'),
(76, 'widget_categories', 'a:0:{}', 'yes'),
(77, 'widget_text', 'a:0:{}', 'yes'),
(78, 'widget_rss', 'a:0:{}', 'yes'),
(79, 'uninstall_plugins', 'a:0:{}', 'no'),
(80, 'timezone_string', 'Europe/Paris', 'yes'),
(81, 'page_for_posts', '0', 'yes'),
(82, 'page_on_front', '36', 'yes'),
(83, 'default_post_format', '0', 'yes'),
(84, 'link_manager_enabled', '0', 'yes'),
(85, 'finished_splitting_shared_terms', '1', 'yes'),
(86, 'site_icon', '0', 'yes'),
(87, 'medium_large_size_w', '768', 'yes'),
(88, 'medium_large_size_h', '0', 'yes'),
(89, 'wp_page_for_privacy_policy', '3', 'yes'),
(90, 'show_comments_cookies_opt_in', '1', 'yes'),
(91, 'admin_email_lifespan', '1734945791', 'yes'),
(92, 'disallowed_keys', '', 'no'),
(93, 'comment_previously_approved', '1', 'yes'),
(94, 'auto_plugin_theme_update_emails', 'a:0:{}', 'no'),
(95, 'auto_update_core_dev', 'enabled', 'yes'),
(96, 'auto_update_core_minor', 'enabled', 'yes'),
(97, 'auto_update_core_major', 'enabled', 'yes'),
(98, 'wp_force_deactivated_plugins', 'a:0:{}', 'yes'),
(99, 'wp_attachment_pages_enabled', '0', 'yes'),
(100, 'initial_db_version', '56657', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:61:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(102, 'fresh_site', '0', 'yes'),
(103, 'WPLANG', 'fr_FR', 'yes'),
(104, 'user_count', '1', 'no'),
(105, 'widget_block', 'a:6:{i:2;a:1:{s:7:"content";s:19:"<!-- wp:search /-->";}i:3;a:1:{s:7:"content";s:159:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Articles récents</h2><!-- /wp:heading --><!-- wp:latest-posts /--></div><!-- /wp:group -->";}i:4;a:1:{s:7:"content";s:233:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Commentaires récents</h2><!-- /wp:heading --><!-- wp:latest-comments {"displayAvatar":false,"displayDate":false,"displayExcerpt":false} /--></div><!-- /wp:group -->";}i:5;a:1:{s:7:"content";s:146:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Archives</h2><!-- /wp:heading --><!-- wp:archives /--></div><!-- /wp:group -->";}i:6;a:1:{s:7:"content";s:151:"<!-- wp:group --><div class="wp-block-group"><!-- wp:heading --><h2>Catégories</h2><!-- /wp:heading --><!-- wp:categories /--></div><!-- /wp:group -->";}s:12:"_multiwidget";i:1;}', 'yes'),
(106, 'sidebars_widgets', 'a:2:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}s:13:"array_version";i:3;}', 'yes'),
(107, 'cron', 'a:10:{i:1723036997;a:1:{s:34:"wp_privacy_delete_old_export_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1723065797;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1723065815;a:1:{s:21:"wp_update_user_counts";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1723075200;a:2:{s:18:"imagify_sync_files";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:22:"wdev_logger_clear_logs";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1723108997;a:2:{s:30:"wp_site_health_scheduled_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}s:32:"recovery_mode_clean_expired_keys";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1723109015;a:2:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}s:25:"delete_expired_transients";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1723109016;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1723550059;a:1:{s:27:"acf_update_site_health_data";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}i:1723627444;a:1:{s:30:"wp_delete_temp_updater_backups";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"weekly";s:4:"args";a:0:{}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes'),
(108, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(109, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(110, 'widget_archives', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(111, 'widget_media_audio', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(112, 'widget_media_image', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(113, 'widget_media_gallery', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(114, 'widget_media_video', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(115, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(116, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(117, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(118, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(119, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(120, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(121, 'widget_custom_html', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(124, 'recovery_keys', 'a:0:{}', 'yes'),
(161, 'finished_updating_comment_type', '1', 'yes'),
(162, 'db_upgraded', '', 'yes'),
(163, 'can_compress_scripts', '1', 'yes'),
(165, 'recently_activated', 'a:2:{s:19:"imagify/imagify.php";i:1723025863;s:45:"ewww-image-optimizer/ewww-image-optimizer.php";i:1723025419;}', 'yes'),
(166, 'theme_mods_twentytwentyfour', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1719394251;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:3:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";}s:9:"sidebar-2";a:2:{i:0;s:7:"block-5";i:1;s:7:"block-6";}}}}', 'no'),
(167, 'current_theme', 'Mota-child', 'yes'),
(168, 'theme_mods_Mota-child', 'a:4:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:9:"main-menu";i:2;s:11:"footer-menu";i:3;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1719395641;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}s:18:"custom_css_post_id";i:-1;}', 'yes'),
(169, 'theme_switched', '', 'yes'),
(176, 'theme_mods_twentytwentytwo', 'a:5:{i:0;b:0;s:19:"wp_classic_sidebars";a:0:{}s:18:"nav_menu_locations";a:0:{}s:18:"custom_css_post_id";i:-1;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1719395666;s:4:"data";a:1:{s:19:"wp_inactive_widgets";a:5:{i:0;s:7:"block-2";i:1;s:7:"block-3";i:2;s:7:"block-4";i:3;s:7:"block-5";i:4;s:7:"block-6";}}}}', 'no'),
(179, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(215, 'wp_calendar_block_has_published_posts', '1', 'yes'),
(248, 'ihaf_activated', 'a:2:{s:6:"wpcode";i:1719474838;s:7:"version";s:6:"2.1.14";}', 'yes'),
(250, 'wpcode_snippets', 'a:0:{}', 'yes'),
(251, 'wpcode_snippets_errors', 'a:0:{}', 'yes'),
(252, 'wpcode_admin_notices', 'a:1:{s:14:"review_request";a:2:{s:4:"time";i:1719474838;s:9:"dismissed";b:0;}}', 'yes'),
(255, 'ihaf_insert_header', '<!doctype html>\r\n<head>\r\n    <link rel=\\"stylesheet\\" href=\\"wp-content\\\\themes\\\\Mota-child\\\\style.css\\">\r\n</head>\r\n<body>\r\n<div class=\\"header-top\\">\r\n    <div class=\\"header-top-logo\\">\r\n        <img src=\\"https://localhost/mota/wp-content/uploads/2024/06/Logo.png\\" alt=\\"logo site\\">\r\n    </div>\r\n    <div>\r\n        <nav class=\\"header-top-menu\\" role=\\"navigation\\" aria-label=\\"\\\'Menu principal\\\', \\\'text-domain\\\'\\">\r\n            <?php\r\n                wp_nav_menu([\r\n                    \\\'theme_location\\\' => \\\'main-menu\\\',\r\n                    \\\'container\\\'      => false, // On retire le conteneur généré par WP\r\n                    \\\'items_wrap\\\'     => \\\'%3$s\\\'\r\n                ]);\r\n            ?>\r\n        </nav>\r\n    </div>\r\n</div>\r\n<div class=\\"header-hero\\">\r\n    <img src=\\"https://localhost/mota/wp-content/uploads/2024/06/nathalie-11-scaled.jpeg\\" alt=\\"Une des photo du catalogue\\">\r\n</div>\r\n\r\n', 'yes'),
(256, 'ihaf_insert_footer', '', 'yes'),
(257, 'ihaf_insert_body', '', 'yes'),
(337, 'wpcf7', 'a:2:{s:7:"version";s:5:"5.9.8";s:13:"bulk_validate";a:4:{s:9:"timestamp";i:1719568525;s:7:"version";s:5:"5.9.6";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(380, 'cptui_new_install', 'false', 'yes'),
(383, 'acf_first_activated_version', '6.3.3', 'yes'),
(384, 'acf_site_health', '{"version":"6.3.4","plugin_type":"Free","wp_version":"6.5.5","mysql_version":"5.5.5-10.4.32-MariaDB","is_multisite":false,"active_theme":{"name":"Mota-child","version":"1.0.0","theme_uri":"","stylesheet":false},"parent_theme":{"name":"Twenty Twenty-Two","version":"1.7","theme_uri":"https:\\/\\/wordpress.org\\/themes\\/twentytwentytwo\\/","stylesheet":false},"active_plugins":{"advanced-custom-fields\\/acf.php":{"name":"Advanced Custom Fields","version":"6.3.4","plugin_uri":"https:\\/\\/www.advancedcustomfields.com"},"contact-form-7\\/wp-contact-form-7.php":{"name":"Contact Form 7","version":"5.9.8","plugin_uri":"https:\\/\\/contactform7.com\\/"},"custom-post-type-ui\\/custom-post-type-ui.php":{"name":"Custom Post Type UI","version":"1.17.1","plugin_uri":"https:\\/\\/github.com\\/WebDevStudios\\/custom-post-type-ui\\/"},"wordpress-importer\\/wordpress-importer.php":{"name":"WordPress Importer","version":"0.8.2","plugin_uri":"https:\\/\\/wordpress.org\\/plugins\\/wordpress-importer\\/"}},"ui_field_groups":"1","php_field_groups":"0","json_field_groups":"0","rest_field_groups":"0","number_of_fields_by_type":{"text":2},"number_of_third_party_fields_by_type":[],"post_types_enabled":true,"ui_post_types":"5","json_post_types":"0","ui_taxonomies":"6","json_taxonomies":"0","rest_api_format":"light","admin_ui_enabled":true,"field_type-modal_enabled":true,"field_settings_tabs_enabled":false,"shortcode_enabled":false,"registered_acf_forms":"0","json_save_paths":1,"json_load_paths":1,"event_first_activated":1719921259,"event_first_created_field_group":1719923932,"last_updated":1722953369}', 'no'),
(386, 'acf_version', '6.3.5', 'yes'),
(387, 'cptui_post_types', 'a:1:{s:5:"photo";a:34:{s:4:"name";s:5:"photo";s:5:"label";s:6:"Photos";s:14:"singular_label";s:5:"Photo";s:11:"description";s:18:"Toutes mes photos.";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:7:"show_ui";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:16:"delete_with_user";s:5:"false";s:12:"show_in_rest";s:4:"true";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:14:"rest_namespace";s:0:"";s:11:"has_archive";s:5:"false";s:18:"has_archive_string";s:0:"";s:19:"exclude_from_search";s:5:"false";s:15:"capability_type";s:4:"post";s:12:"hierarchical";s:5:"false";s:10:"can_export";s:5:"false";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:13:"menu_position";s:0:"";s:12:"show_in_menu";s:4:"true";s:19:"show_in_menu_string";s:0:"";s:9:"menu_icon";N;s:20:"register_meta_box_cb";N;s:8:"supports";a:3:{i:0;s:5:"title";i:1;s:6:"editor";i:2;s:9:"thumbnail";}s:10:"taxonomies";a:0:{}s:6:"labels";a:31:{s:9:"menu_name";s:10:"Mes photos";s:9:"all_items";s:17:"Toutes les photos";s:7:"add_new";s:17:"Ajouter une photo";s:12:"add_new_item";s:26:"Ajouter une nouvelle photo";s:9:"edit_item";s:17:"Modifier la photo";s:8:"new_item";s:14:"Nouvelle photo";s:9:"view_item";s:13:"Voir la photo";s:10:"view_items";s:15:"Voir les photos";s:12:"search_items";s:20:"Rechercher une photo";s:9:"not_found";s:21:"Aucune photo trouvée";s:18:"not_found_in_trash";s:30:"Aucune photo trouvée in trash";s:6:"parent";s:12:"Photo mère:";s:14:"featured_image";s:14:"Featured image";s:18:"set_featured_image";s:18:"Set featured image";s:21:"remove_featured_image";s:21:"Remove featured image";s:18:"use_featured_image";s:18:"Use featured image";s:8:"archives";s:15:"Archives photos";s:16:"insert_into_item";s:17:"Insert into photo";s:21:"uploaded_to_this_item";s:22:"Uploaded to this photo";s:17:"filter_items_list";s:18:"Filtrer les photos";s:21:"items_list_navigation";s:21:"Photo list navigation";s:10:"items_list";s:16:"Liste des photos";s:10:"attributes";s:28:"Caractéristiques des photos";s:14:"name_admin_bar";s:5:"Photo";s:14:"item_published";s:14:"Photo publiée";s:24:"item_published_privately";s:24:"Photo publiée en privé";s:22:"item_reverted_to_draft";s:31:"Photo transformée en brouillon";s:12:"item_trashed";s:25:"Photo mise à la poubelle";s:14:"item_scheduled";s:17:"Photo plannifiée";s:12:"item_updated";s:18:"Photo mise à jour";s:17:"parent_item_colon";s:12:"Photo mère:";}s:15:"custom_supports";s:0:"";s:16:"enter_title_here";s:9:"Add title";}}', 'yes'),
(391, 'cptui_taxonomies', 'a:3:{s:9:"categorie";a:28:{s:4:"name";s:9:"categorie";s:5:"label";s:11:"Catégories";s:14:"singular_label";s:10:"Catégorie";s:11:"description";s:41:"Type d&#39;évènement sujet de la photo.";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:12:"hierarchical";s:5:"false";s:7:"show_ui";s:4:"true";s:12:"show_in_menu";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";s:17:"show_admin_column";s:5:"false";s:12:"show_in_rest";s:4:"true";s:13:"show_tagcloud";s:5:"false";s:4:"sort";s:5:"false";s:18:"show_in_quick_edit";s:0:"";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:14:"rest_namespace";s:0:"";s:6:"labels";a:23:{s:9:"menu_name";s:11:"Catégories";s:9:"all_items";s:22:"Toutes les catégories";s:9:"edit_item";s:19:"Modifier catégorie";s:9:"view_item";s:18:"Voir la catégorie";s:11:"update_item";s:32:"Modifier le nom de la catégorie";s:12:"add_new_item";s:31:"Ajouter une nouvelle catégorie";s:13:"new_item_name";s:25:"Nouveau nom de catégorie";s:11:"parent_item";s:17:"Catégorie mère:";s:17:"parent_item_colon";s:17:"Catégorie mère:";s:12:"search_items";s:25:"Rechercher une catégorie";s:13:"popular_items";s:22:"Catégories populaires";s:26:"separate_items_with_commas";s:40:"Séparer les catégories par une virgule";s:19:"add_or_remove_items";s:35:"Ajouter ou supprimer une catégorie";s:21:"choose_from_most_used";s:40:"Issus de la catégorie la plus utilisée";s:9:"not_found";s:26:"Aucune catégorie trouvée";s:8:"no_terms";s:17:"Aucune catégorie";s:21:"items_list_navigation";s:24:"Category list navigation";s:10:"items_list";s:21:"Liste des catégories";s:13:"back_to_items";s:22:"Retour aux catégories";s:22:"name_field_description";s:26:"Nom tel que vu sur le site";s:24:"parent_field_description";s:18:"Assigner un parent";s:22:"slug_field_description";s:29:"Lowercase version of the name";s:22:"desc_field_description";s:0:"";}s:11:"meta_box_cb";s:0:"";s:12:"default_term";s:0:"";s:12:"object_types";a:1:{i:0;s:5:"photo";}}s:6:"format";a:28:{s:4:"name";s:6:"format";s:5:"label";s:7:"Formats";s:14:"singular_label";s:6:"Format";s:11:"description";s:45:"Orientation de la photo: portrait ou paysage.";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:12:"hierarchical";s:5:"false";s:7:"show_ui";s:4:"true";s:12:"show_in_menu";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";s:17:"show_admin_column";s:5:"false";s:12:"show_in_rest";s:4:"true";s:13:"show_tagcloud";s:5:"false";s:4:"sort";s:5:"false";s:18:"show_in_quick_edit";s:0:"";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:14:"rest_namespace";s:0:"";s:6:"labels";a:23:{s:9:"menu_name";s:6:"Format";s:9:"all_items";s:16:"Tous les formats";s:9:"edit_item";s:18:"Modifier un format";s:9:"view_item";s:16:"Voir les formats";s:11:"update_item";s:35:"Modifier le nom d&amp;#39;un format";s:12:"add_new_item";s:25:"Ajouter un nouveau format";s:13:"new_item_name";s:32:"Ajouter un nouveau nom de format";s:11:"parent_item";s:13:"Format parent";s:17:"parent_item_colon";s:14:"Format parent:";s:12:"search_items";s:20:"Rechercher un format";s:13:"popular_items";s:18:"Formats populaires";s:26:"separate_items_with_commas";s:36:"Séparer les formats par une virgule";s:19:"add_or_remove_items";s:30:"Ajouter ou supprimer un format";s:21:"choose_from_most_used";s:32:"Issus du format le plus utilisé";s:9:"not_found";s:20:"Aucun format trouvé";s:8:"no_terms";s:12:"Aucun format";s:21:"items_list_navigation";s:22:"Format list navigation";s:10:"items_list";s:17:"Liste des formats";s:13:"back_to_items";s:18:"Retour aux formats";s:22:"name_field_description";s:26:"Nom tel que vu sur le site";s:24:"parent_field_description";s:18:"Assigner un parent";s:22:"slug_field_description";s:14:"Lowercase name";s:22:"desc_field_description";s:0:"";}s:11:"meta_box_cb";s:0:"";s:12:"default_term";s:0:"";s:12:"object_types";a:1:{i:0;s:5:"photo";}}s:5:"annee";a:28:{s:4:"name";s:5:"annee";s:5:"label";s:7:"Années";s:14:"singular_label";s:6:"Année";s:11:"description";s:25:"Année de la prise de vue";s:6:"public";s:4:"true";s:18:"publicly_queryable";s:4:"true";s:12:"hierarchical";s:5:"false";s:7:"show_ui";s:4:"true";s:12:"show_in_menu";s:4:"true";s:17:"show_in_nav_menus";s:4:"true";s:9:"query_var";s:4:"true";s:14:"query_var_slug";s:0:"";s:7:"rewrite";s:4:"true";s:12:"rewrite_slug";s:0:"";s:17:"rewrite_withfront";s:1:"1";s:20:"rewrite_hierarchical";s:1:"0";s:17:"show_admin_column";s:5:"false";s:12:"show_in_rest";s:4:"true";s:13:"show_tagcloud";s:5:"false";s:4:"sort";s:5:"false";s:18:"show_in_quick_edit";s:0:"";s:9:"rest_base";s:0:"";s:21:"rest_controller_class";s:0:"";s:14:"rest_namespace";s:0:"";s:6:"labels";a:23:{s:9:"menu_name";s:7:"Années";s:9:"all_items";s:16:"Tous les Années";s:9:"edit_item";s:15:"Modifier Année";s:9:"view_item";s:11:"Voir Année";s:11:"update_item";s:31:"Mettre à jour le nom de Année";s:12:"add_new_item";s:25:"Ajouter un nouveau Année";s:13:"new_item_name";s:21:"Nom du nouveau Année";s:11:"parent_item";s:14:"Parent dAnnée";s:17:"parent_item_colon";s:16:"Année parent :";s:12:"search_items";s:20:"Recherche de Années";s:13:"popular_items";s:18:"Années populaires";s:26:"separate_items_with_commas";s:38:"Séparer les Années avec des virgules";s:19:"add_or_remove_items";s:32:"Ajouter ou supprimer des Années";s:21:"choose_from_most_used";s:44:"Choisir parmi les Années les plus utilisés";s:9:"not_found";s:21:"Aucun Années trouvé";s:8:"no_terms";s:13:"Aucun Années";s:21:"items_list_navigation";s:30:"Navigation de liste de Années";s:10:"items_list";s:16:"Liste de Années";s:13:"back_to_items";s:20:"Retourner à Années";s:22:"name_field_description";s:46:"Le nom tel qu’il apparaîtra sur votre site.";s:24:"parent_field_description";s:144:"Assigner un terme parent pour créer une hiérarchie. Le terme « Jazz », par exemple, serait le parent de « Bebop » et « Big Band ».";s:22:"slug_field_description";s:168:"Le « slug » est une version du nom compatible avec les URL. Il est généralement entièrement en minuscules et contient uniquement des lettres, chiffres et tirets.";s:22:"desc_field_description";s:109:"La description n’est pas mise en évidence par défaut ; toutefois, certains thèmes peuvent l’afficher.";}s:11:"meta_box_cb";s:0:"";s:12:"default_term";s:0:"";s:12:"object_types";a:1:{i:0;s:5:"photo";}}}', 'yes'),
(411, 'recovery_mode_email_last_sent', '1723033069', 'yes'),
(1029, 'ewww_image_optimizer_relative_migration_status', 'done', 'yes'),
(1031, 'ewww_image_optimizer_background_optimization', '1', 'no'),
(1032, 'ewww_image_optimizer_noauto', '', 'yes'),
(1033, 'ewww_image_optimizer_disable_editor', '', 'yes'),
(1034, 'ewww_image_optimizer_debug', '', 'yes'),
(1035, 'ewww_image_optimizer_metadata_remove', '1', 'yes'),
(1036, 'ewww_image_optimizer_jpg_level', '10', 'yes'),
(1037, 'ewww_image_optimizer_png_level', '10', 'yes'),
(1038, 'ewww_image_optimizer_gif_level', '10', 'yes'),
(1039, 'ewww_image_optimizer_pdf_level', '0', 'yes'),
(1040, 'ewww_image_optimizer_svg_level', '0', 'yes'),
(1041, 'ewww_image_optimizer_jpg_quality', '', 'yes'),
(1042, 'ewww_image_optimizer_webp_quality', '', 'yes'),
(1043, 'ewww_image_optimizer_backup_files', 'local', 'yes'),
(1044, 'ewww_image_optimizer_resize_existing', '1', 'yes'),
(1045, 'ewww_image_optimizer_exactdn', '', 'yes'),
(1046, 'ewww_image_optimizer_exactdn_plan_id', '0', 'yes'),
(1047, 'exactdn_all_the_things', '1', 'yes'),
(1048, 'exactdn_lossy', '1', 'yes'),
(1049, 'exactdn_exclude', '', 'yes'),
(1050, 'exactdn_sub_folder', '', 'no'),
(1051, 'exactdn_prevent_db_queries', '', 'yes'),
(1052, 'exactdn_asset_domains', '', 'yes'),
(1053, 'ewww_image_optimizer_lazy_load', '1', 'yes'),
(1054, 'ewww_image_optimizer_add_missing_dims', '', 'yes'),
(1055, 'ewww_image_optimizer_use_siip', '', 'yes'),
(1056, 'ewww_image_optimizer_use_lqip', '', 'yes'),
(1057, 'ewww_image_optimizer_use_dcip', '', 'yes'),
(1058, 'ewww_image_optimizer_ll_exclude', '', 'yes'),
(1059, 'ewww_image_optimizer_ll_all_things', '', 'yes'),
(1060, 'ewww_image_optimizer_disable_pngout', '1', 'yes'),
(1061, 'ewww_image_optimizer_disable_svgcleaner', '1', 'yes'),
(1062, 'ewww_image_optimizer_optipng_level', '2', 'yes'),
(1063, 'ewww_image_optimizer_pngout_level', '2', 'yes'),
(1064, 'ewww_image_optimizer_webp_for_cdn', '', 'yes'),
(1065, 'ewww_image_optimizer_force_gif2webp', '1', 'yes'),
(1066, 'ewww_image_optimizer_picture_webp', '', 'yes'),
(1067, 'ewww_image_optimizer_webp_rewrite_exclude', '', 'yes'),
(1070, 'ewww_image_optimizer_ll_autoscale', '1', 'no'),
(1071, 'exactdn_never_been_active', '1', 'no'),
(1072, 'ewww_image_optimizer_bulk_resume', '', 'yes'),
(1073, 'ewww_image_optimizer_aux_resume', '', 'yes'),
(1074, 'ewww_image_optimizer_flag_attachments', '', 'no'),
(1075, 'ewww_image_optimizer_ngg_attachments', '', 'no'),
(1077, 'ewww_image_optimizer_review_time', '1723629037', 'no'),
(1078, 'ewww_image_optimizer_version', '780', 'yes'),
(1081, 'ewww_image_optimizer_goal_site_speed', '1', 'no'),
(1082, 'ewww_image_optimizer_webp', '1', 'yes'),
(1083, 'ewww_image_optimizer_maxmediawidth', '1920', 'yes'),
(1084, 'ewww_image_optimizer_maxmediaheight', '1920', 'yes'),
(1085, 'ewww_image_optimizer_wizard_complete', '1', 'no'),
(1086, 'ewww_image_optimizer_dismiss_media_notice', '1', 'no') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1326, 'action_scheduler_hybrid_store_demarkation', '92', 'yes'),
(1327, 'schema-ActionScheduler_StoreSchema', '7.0.1723025823', 'yes'),
(1328, 'schema-ActionScheduler_LoggerSchema', '3.0.1723025824', 'yes'),
(1331, 'action_scheduler_lock_async-request-runner', '66b349a017f3a4.34341361|1723025884', 'no'),
(1349, 'wp-smush-settings', 'a:27:{s:4:"auto";b:0;s:5:"lossy";i:0;s:10:"strip_exif";b:1;s:6:"resize";b:0;s:9:"detection";b:0;s:8:"original";b:0;s:6:"backup";b:0;s:8:"no_scale";b:0;s:10:"png_to_jpg";b:0;s:7:"nextgen";b:0;s:2:"s3";b:0;s:9:"gutenberg";b:0;s:10:"js_builder";b:0;s:5:"gform";b:0;s:3:"cdn";b:0;s:11:"auto_resize";b:0;s:4:"webp";b:1;s:5:"usage";b:0;s:17:"accessible_colors";b:0;s:9:"keep_data";b:1;s:9:"lazy_load";b:1;s:17:"background_images";b:1;s:16:"rest_api_support";b:0;s:8:"webp_mod";b:0;s:16:"background_email";b:0;s:22:"webp_direct_conversion";b:0;s:13:"webp_fallback";b:0;}', 'yes'),
(1350, 'wp-smush-install-type', 'existing', 'no'),
(1351, 'wp-smush-version', '3.16.6', 'no'),
(1355, 'wpmudev_recommended_plugins_registered', 'a:1:{s:23:"wp-smushit/wp-smush.php";a:1:{s:13:"registered_at";i:1723026390;}}', 'no'),
(1356, 'wp_smush_pre_3_12_6_site', '0', 'no'),
(1358, 'wp_smush_image_sizes_state', 'a:2:{s:5:"sizes";a:6:{s:9:"thumbnail";a:3:{s:5:"width";s:3:"150";s:6:"height";s:3:"150";s:4:"crop";b:1;}s:6:"medium";a:3:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";b:0;}s:5:"large";a:3:{s:5:"width";s:4:"1024";s:6:"height";s:4:"1024";s:4:"crop";b:0;}s:9:"1536x1536";a:3:{s:5:"width";i:1536;s:6:"height";i:1536;s:4:"crop";b:0;}s:9:"2048x2048";a:3:{s:5:"width";i:2048;s:6:"height";i:2048;s:4:"crop";b:0;}s:12:"medium_large";a:2:{s:5:"width";i:768;s:6:"height";i:0;}}s:4:"hash";i:46247379563;}', 'yes'),
(1362, 'wpmudev_notices', 'a:3:{s:7:"plugins";a:1:{s:5:"smush";i:1723026404;}s:5:"queue";a:1:{s:5:"smush";a:2:{s:4:"rate";i:1723631204;s:8:"giveaway";i:1723199204;}}s:4:"done";a:1:{s:5:"smush";a:1:{s:5:"email";i:1723026871;}}}', 'no'),
(1363, 'wp-smush-preset_configs', 'a:1:{i:0;a:5:{s:2:"id";i:1;s:4:"name";s:14:"Default config";s:11:"description";s:46:"Recommended performance config for every site.";s:7:"default";b:1;s:6:"config";a:2:{s:7:"configs";a:1:{s:8:"settings";a:23:{s:4:"auto";b:1;s:5:"lossy";i:1;s:10:"strip_exif";b:1;s:6:"resize";b:0;s:9:"detection";b:0;s:8:"original";b:1;s:6:"backup";b:1;s:10:"png_to_jpg";b:1;s:16:"background_email";b:0;s:7:"nextgen";b:0;s:2:"s3";b:0;s:9:"gutenberg";b:0;s:10:"js_builder";b:0;s:3:"cdn";b:0;s:11:"auto_resize";b:0;s:4:"webp";b:1;s:5:"usage";b:0;s:17:"accessible_colors";b:0;s:9:"keep_data";b:1;s:9:"lazy_load";b:0;s:17:"background_images";b:1;s:16:"rest_api_support";b:0;s:8:"webp_mod";b:0;}}s:7:"strings";a:6:{s:10:"bulk_smush";a:1:{i:0;s:221:"Smush Mode - Super\r\nAutomatic compression - Active\r\nMetadata - Active\r\nImage Resizing - Inactive\r\nOriginal Images - Active\r\nBackup Original Images - Active\r\nPNG to JPEG Conversion - Inactive\r\nEmail Notification - Inactive";}s:9:"lazy_load";a:1:{i:0;s:8:"Inactive";}s:3:"cdn";a:1:{i:0;s:8:"Inactive";}s:8:"webp_mod";a:1:{i:0;s:8:"Inactive";}s:12:"integrations";a:1:{i:0;s:112:"Gutenberg Support - Inactive\r\nWPBakery Page Builder - Inactive\r\nAmazon S3 - Inactive\r\nNextGen Gallery - Inactive";}s:8:"settings";a:1:{i:0;s:125:"Image Resize Detection - Inactive\r\nColor Accessibility - Inactive\r\nUsage Tracking - Inactive\r\nKeep Data On Uninstall - Active";}}}}}', 'no'),
(1364, 'wp-smush-lazy_load', 'a:9:{s:6:"format";a:6:{s:4:"jpeg";b:1;s:3:"png";b:1;s:4:"webp";b:1;s:3:"gif";b:1;s:3:"svg";b:1;s:6:"iframe";b:1;}s:6:"output";a:4:{s:7:"content";b:1;s:7:"widgets";b:1;s:10:"thumbnails";b:1;s:9:"gravatars";b:1;}s:9:"animation";a:4:{s:8:"selected";s:6:"fadein";s:6:"fadein";a:2:{s:8:"duration";i:400;s:5:"delay";i:0;}s:7:"spinner";a:2:{s:8:"selected";i:1;s:6:"custom";a:0:{}}s:11:"placeholder";a:3:{s:8:"selected";i:1;s:6:"custom";a:0:{}s:5:"color";s:7:"#F3F3F3";}}s:7:"include";a:7:{s:9:"frontpage";b:1;s:4:"home";b:1;s:4:"page";b:1;s:6:"single";b:1;s:7:"archive";b:1;s:8:"category";b:1;s:3:"tag";b:1;}s:13:"exclude-pages";a:0:{}s:15:"exclude-classes";a:0:{}s:6:"footer";b:1;s:6:"native";b:0;s:8:"noscript";b:0;}', 'yes'),
(1365, 'skip-smush-setup', '1', 'yes'),
(1368, 'dir_smush_stats', 'a:1:{s:9:"dir_smush";a:2:{s:5:"total";i:0;s:9:"optimised";i:0;}}', 'no'),
(1369, 'wp_smush_background_pre_flight', 'a:2:{s:8:"loopback";i:1723026490;s:4:"cron";i:1723026500;}', 'no'),
(1371, 'wp-smush-optimization-global-stats', 'a:8:{s:4:"time";d:9.250000000000002;s:5:"bytes";i:79490;s:7:"percent";d:0.39;s:11:"size_before";i:20510749;s:10:"size_after";i:20431259;s:5:"count";i:18;s:14:"attachment_ids";s:51:"5,8,47,48,49,50,51,52,53,54,56,57,58,59,60,61,64,55";s:11:"lossy_count";i:0;}', 'no'),
(1372, 'wp-smush-png2jpg-global-stats', 'a:7:{s:4:"time";d:0;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:0;s:10:"size_after";i:0;s:5:"count";i:0;s:14:"attachment_ids";s:0:"";}', 'no'),
(1373, 'wp-smush-resize-global-stats', 'a:7:{s:4:"time";d:0;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:0;s:10:"size_after";i:0;s:5:"count";i:0;s:14:"attachment_ids";s:0:"";}', 'no'),
(1374, 'wp_smush_global_stats', 'a:4:{s:30:"stats_update_started_timestamp";i:1723026494;s:22:"image_attachment_count";i:20;s:22:"optimized_images_count";i:115;s:23:"stats_updated_timestamp";i:1723026497;}', 'no'),
(1375, 'wp_smush_background_scan_process_status', 'a:7:{s:13:"in_processing";b:0;s:12:"is_cancelled";b:0;s:12:"is_completed";b:1;s:11:"total_items";i:1;s:15:"processed_items";i:1;s:12:"failed_items";i:0;s:7:"is_dead";b:0;}', 'no'),
(1382, 'wp-smush-optimize-list', '', 'no'),
(1386, 'wp-smush-reoptimize-list', '', 'no'),
(1387, 'wp-smush-error-items-list', '', 'no'),
(1388, 'wp-smush-ignored-items-list', '', 'no'),
(1389, 'wp-smush-animated-items-list', '', 'no'),
(1445, 'new_admin_email', 'erchluprev@gmail.com', 'yes'),
(1455, 'wpmdb_usage', 'a:2:{s:6:"action";s:8:"savefile";s:4:"time";i:1723033914;}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=345 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 3, '_wp_page_template', 'default'),
(3, 5, '_wp_attached_file', '2024/06/Logo.png'),
(4, 5, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:690;s:6:"height";i:44;s:4:"file";s:16:"2024/06/Logo.png";s:8:"filesize";i:2157;s:5:"sizes";a:2:{s:6:"medium";a:5:{s:4:"file";s:15:"Logo-300x19.png";s:5:"width";i:300;s:6:"height";i:19;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:2171;}s:9:"thumbnail";a:5:{s:4:"file";s:15:"Logo-150x44.png";s:5:"width";i:150;s:6:"height";i:44;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:317;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(23, 8, '_wp_attached_file', '2024/06/nathalie-11-scaled.jpeg'),
(24, 8, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1920;s:6:"height";i:1282;s:4:"file";s:31:"2024/06/nathalie-11-scaled.jpeg";s:8:"filesize";i:223881;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-11-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15336;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-11-1024x684.jpeg";s:5:"width";i:1024;s:6:"height";i:684;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:89733;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-11-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7628;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-11-768x513.jpeg";s:5:"width";i:768;s:6:"height";i:513;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:59680;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-11-1536x1025.jpeg";s:5:"width";i:1536;s:6:"height";i:1025;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:160800;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-11-2048x1367.jpeg";s:5:"width";i:2048;s:6:"height";i:1367;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:248616;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-11.jpeg";}'),
(39, 15, 'is_wp_suggestion', ''),
(40, 17, '_edit_lock', '1719492688:1'),
(41, 17, '_wp_page_template', ''),
(42, 22, '_wpcode_auto_insert', '1'),
(43, 22, '_wpcode_auto_insert_number', '1'),
(44, 23, '_wpcode_auto_insert', '1'),
(45, 23, '_wpcode_library_id', '12'),
(46, 26, '_menu_item_type', 'post_type'),
(47, 26, '_menu_item_menu_item_parent', '0'),
(48, 26, '_menu_item_object_id', '17'),
(49, 26, '_menu_item_object', 'page'),
(50, 26, '_menu_item_target', ''),
(51, 26, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(52, 26, '_menu_item_xfn', ''),
(53, 26, '_menu_item_url', ''),
(57, 3, '_edit_lock', '1719493612:1'),
(58, 32, '_edit_lock', '1719490851:1'),
(59, 34, '_menu_item_type', 'post_type'),
(60, 34, '_menu_item_menu_item_parent', '0'),
(61, 34, '_menu_item_object_id', '3'),
(62, 34, '_menu_item_object', 'page'),
(63, 34, '_menu_item_target', ''),
(64, 34, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(65, 34, '_menu_item_xfn', ''),
(66, 34, '_menu_item_url', ''),
(68, 35, '_menu_item_type', 'post_type'),
(69, 35, '_menu_item_menu_item_parent', '0'),
(70, 35, '_menu_item_object_id', '32'),
(71, 35, '_menu_item_object', 'page'),
(72, 35, '_menu_item_target', ''),
(73, 35, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(74, 35, '_menu_item_xfn', ''),
(75, 35, '_menu_item_url', ''),
(77, 36, '_edit_lock', '1721124629:1'),
(78, 39, '_menu_item_type', 'post_type'),
(79, 39, '_menu_item_menu_item_parent', '0'),
(80, 39, '_menu_item_object_id', '36'),
(81, 39, '_menu_item_object', 'page'),
(82, 39, '_menu_item_target', ''),
(83, 39, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(84, 39, '_menu_item_xfn', ''),
(85, 39, '_menu_item_url', ''),
(87, 40, '_form', '<label> Your name\n    [text* your-name autocomplete:name] </label>\n\n<label> Your email\n    [email* your-email autocomplete:email] </label>\n\n<label> Subject\n    [text* your-subject] </label>\n\n<label> Your message (optional)\n    [textarea your-message] </label>\n\n[submit "Submit"]'),
(88, 40, '_mail', 'a:8:{s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:36:"[_site_title] <erchluprev@gmail.com>";s:4:"body";s:191:"From: [your-name] [your-email]\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis is a notification that a contact form was submitted on your website ([_site_title] [_site_url]).";s:9:"recipient";s:19:"[_site_admin_email]";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(89, 40, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:36:"[_site_title] <erchluprev@gmail.com>";s:4:"body";s:220:"Message Body:\n[your-message]\n\n-- \nThis email is a receipt for your contact form submission on our website ([_site_title] [_site_url]) in which your email address was used. If that was not you, please ignore this message.";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:29:"Reply-To: [_site_admin_email]";s:11:"attachments";s:0:"";s:8:"use_html";i:0;s:13:"exclude_blank";i:0;}'),
(90, 40, '_messages', 'a:12:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:27:"Please fill out this field.";s:16:"invalid_too_long";s:32:"This field has a too long input.";s:17:"invalid_too_short";s:33:"This field has a too short input.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:31:"The uploaded file is too large.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";}'),
(91, 40, '_additional_settings', ''),
(92, 40, '_locale', 'fr_FR'),
(93, 40, '_hash', '7dc2885648063630a21a1950c430d795da70f16a'),
(94, 41, '_form', '<label> NOM </label>\n    [text* your-name autocomplete:name]\n\n<label> E-MAIL\n    [email* your-email autocomplete:email] </label>\n\n<label id="modale-ref-photo" value="hein?"> RÉF. PHOTO (optional)\n    [text* your-subject] </label>\n\n<label> MESSAGE\n    [textarea your-message] </label>\n\n[submit "Envoyer"]'),
(95, 41, '_mail', 'a:9:{s:6:"active";b:1;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:36:"[_site_title] <erchluprev@gmail.com>";s:9:"recipient";s:19:"[_site_admin_email]";s:4:"body";s:191:"From: [your-name] [your-email]\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis is a notification that a contact form was submitted on your website ([_site_title] [_site_url]).";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(96, 41, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:30:"[_site_title] "[your-subject]"";s:6:"sender";s:36:"[_site_title] <erchluprev@gmail.com>";s:9:"recipient";s:12:"[your-email]";s:4:"body";s:220:"Message Body:\n[your-message]\n\n-- \nThis email is a receipt for your contact form submission on our website ([_site_title] [_site_url]) in which your email address was used. If that was not you, please ignore this message.";s:18:"additional_headers";s:29:"Reply-To: [_site_admin_email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(97, 41, '_messages', 'a:22:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:27:"Please fill out this field.";s:16:"invalid_too_long";s:32:"This field has a too long input.";s:17:"invalid_too_short";s:33:"This field has a too short input.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:31:"The uploaded file is too large.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";s:12:"invalid_date";s:41:"Please enter a date in YYYY-MM-DD format.";s:14:"date_too_early";s:32:"This field has a too early date.";s:13:"date_too_late";s:31:"This field has a too late date.";s:14:"invalid_number";s:22:"Please enter a number.";s:16:"number_too_small";s:34:"This field has a too small number.";s:16:"number_too_large";s:34:"This field has a too large number.";s:23:"quiz_answer_not_correct";s:36:"The answer to the quiz is incorrect.";s:13:"invalid_email";s:30:"Please enter an email address.";s:11:"invalid_url";s:19:"Please enter a URL.";s:11:"invalid_tel";s:32:"Please enter a telephone number.";}'),
(98, 41, '_additional_settings', ''),
(99, 41, '_locale', 'fr_FR'),
(100, 41, '_hash', 'e6c5c1af6b832d3c6e41d09d6b709c1656ff7f1b'),
(101, 42, '_edit_last', '1'),
(102, 42, '_edit_lock', '1720093124:1'),
(103, 46, '_edit_lock', '1720524244:1'),
(104, 46, '_thumbnail_id', '8'),
(105, 46, '_edit_last', '1'),
(106, 46, 'type', 'Argentique'),
(107, 46, '_type', 'field_6683f3962a846'),
(108, 46, 'reference', 'bf2396'),
(109, 46, '_reference', 'field_6683f4f9725e4'),
(110, 46, '_wp_page_template', 'templates/single.php'),
(111, 46, '_wp_old_date', '2024-07-02'),
(112, 47, '_wp_attached_file', '2024/07/nathalie-4-scaled.jpeg'),
(113, 47, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1280;s:6:"height";i:1920;s:4:"file";s:30:"2024/07/nathalie-4-scaled.jpeg";s:8:"filesize";i:405064;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-4-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19120;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-4-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:154007;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-4-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8301;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-4-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:185149;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-4-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:293652;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-4-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:465707;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-4.jpeg";}'),
(114, 48, '_wp_attached_file', '2024/07/nathalie-5-scaled.jpeg'),
(115, 48, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1280;s:6:"height";i:1920;s:4:"file";s:30:"2024/07/nathalie-5-scaled.jpeg";s:8:"filesize";i:442954;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-5-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19961;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-5-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:157234;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-5-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8796;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-5-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:190989;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-5-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:314409;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-5-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:530969;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-5.jpeg";}'),
(116, 49, '_wp_attached_file', '2024/07/nathalie-6-scaled.jpeg'),
(117, 49, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1920;s:6:"height";i:1536;s:4:"file";s:30:"2024/07/nathalie-6-scaled.jpeg";s:8:"filesize";i:383266;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-6-300x240.jpeg";s:5:"width";i:300;s:6:"height";i:240;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:15227;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-6-1024x819.jpeg";s:5:"width";i:1024;s:6:"height";i:819;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:119012;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-6-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6182;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-6-768x614.jpeg";s:5:"width";i:768;s:6:"height";i:614;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:70991;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-6-1536x1229.jpeg";s:5:"width";i:1536;s:6:"height";i:1229;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:257672;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-6-2048x1638.jpeg";s:5:"width";i:2048;s:6:"height";i:1638;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:459400;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-6.jpeg";}'),
(118, 50, '_wp_attached_file', '2024/07/nathalie-7-scaled.jpeg'),
(119, 50, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:30:"2024/07/nathalie-7-scaled.jpeg";s:8:"filesize";i:241524;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-7-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14142;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-7-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:93348;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-7-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:6471;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-7-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:60109;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-7-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:172849;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-7-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:270591;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-7.jpeg";}'),
(120, 51, '_wp_attached_file', '2024/07/nathalie-8-scaled.jpeg'),
(121, 51, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1282;s:6:"height";i:1920;s:4:"file";s:30:"2024/07/nathalie-8-scaled.jpeg";s:8:"filesize";i:277623;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-8-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:17497;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-8-684x1024.jpeg";s:5:"width";i:684;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:110018;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-8-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9130;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-8-768x1150.jpeg";s:5:"width";i:768;s:6:"height";i:1150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:130484;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-8-1025x1536.jpeg";s:5:"width";i:1025;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:201564;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-8-1367x2048.jpeg";s:5:"width";i:1367;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:311207;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-8.jpeg";}'),
(122, 52, '_wp_attached_file', '2024/07/nathalie-9-scaled.jpeg'),
(123, 52, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:30:"2024/07/nathalie-9-scaled.jpeg";s:8:"filesize";i:345581;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-9-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14940;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-9-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:117812;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-9-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7473;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-9-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:71411;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-9-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:239467;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-9-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:409691;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-9.jpeg";}'),
(124, 53, '_wp_attached_file', '2024/07/nathalie-10-scaled.jpeg'),
(125, 53, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1920;s:6:"height";i:1440;s:4:"file";s:31:"2024/07/nathalie-10-scaled.jpeg";s:8:"filesize";i:785980;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-10-300x225.jpeg";s:5:"width";i:300;s:6:"height";i:225;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:27080;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-10-1024x768.jpeg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:274903;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-10-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9640;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-10-768x576.jpeg";s:5:"width";i:768;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:160205;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-10-1536x1152.jpeg";s:5:"width";i:1536;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:570623;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-10-2048x1536.jpeg";s:5:"width";i:2048;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:932555;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-10.jpeg";}'),
(126, 54, '_wp_attached_file', '2024/07/nathalie-12-scaled.jpeg'),
(127, 54, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:31:"2024/07/nathalie-12-scaled.jpeg";s:8:"filesize";i:317437;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-12-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19079;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-12-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:126466;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-12-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9639;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-12-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:81539;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-12-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:230351;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-12-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:355826;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-12.jpeg";}'),
(128, 55, '_wp_attached_file', '2024/07/nathalie-13-scaled.jpeg'),
(129, 55, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1280;s:6:"height";i:1920;s:4:"file";s:31:"2024/07/nathalie-13-scaled.jpeg";s:8:"filesize";i:171816;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-13-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10566;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-13-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:67140;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-13-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5724;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-13-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:79879;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-13-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:122912;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-13-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:191523;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-13.jpeg";}'),
(130, 56, '_wp_attached_file', '2024/07/nathalie-14-scaled.jpeg'),
(131, 56, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1280;s:6:"height";i:1920;s:4:"file";s:31:"2024/07/nathalie-14-scaled.jpeg";s:8:"filesize";i:274509;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-14-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:11670;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-14-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:97840;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-14-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:5583;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-14-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:119233;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-14-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:195817;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-14-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:321282;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-14.jpeg";}'),
(132, 57, '_wp_attached_file', '2024/07/nathalie-15-scaled.jpeg'),
(133, 57, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1709;s:6:"height";i:2560;s:4:"file";s:31:"2024/07/nathalie-15-scaled.jpeg";s:8:"filesize";i:685796;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:24:"nathalie-15-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21406;}s:5:"large";a:5:{s:4:"file";s:25:"nathalie-15-684x1024.jpeg";s:5:"width";i:684;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:162353;}s:9:"thumbnail";a:5:{s:4:"file";s:24:"nathalie-15-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9111;}s:12:"medium_large";a:5:{s:4:"file";s:25:"nathalie-15-768x1150.jpeg";s:5:"width";i:768;s:6:"height";i:1150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:194862;}s:9:"1536x1536";a:5:{s:4:"file";s:26:"nathalie-15-1025x1536.jpeg";s:5:"width";i:1025;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:310272;}s:9:"2048x2048";a:5:{s:4:"file";s:26:"nathalie-15-1367x2048.jpeg";s:5:"width";i:1367;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:484463;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:16:"nathalie-15.jpeg";}'),
(134, 58, '_wp_attached_file', '2024/07/nathalie-0-scaled.jpeg'),
(135, 58, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:30:"2024/07/nathalie-0-scaled.jpeg";s:8:"filesize";i:223228;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-0-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:14686;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-0-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:86728;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-0-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:7332;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-0-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:56932;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-0-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:158178;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-0-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:250852;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-0.jpeg";}'),
(136, 59, '_wp_attached_file', '2024/07/nathalie-1-scaled.jpeg'),
(137, 59, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1920;s:6:"height";i:1280;s:4:"file";s:30:"2024/07/nathalie-1-scaled.jpeg";s:8:"filesize";i:366385;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-1-300x200.jpeg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:19299;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-1-1024x683.jpeg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:138484;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-1-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:8613;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-1-768x512.jpeg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:87873;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-1-1536x1024.jpeg";s:5:"width";i:1536;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:263799;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-1-2048x1365.jpeg";s:5:"width";i:2048;s:6:"height";i:1365;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:421371;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-1.jpeg";}'),
(138, 60, '_wp_attached_file', '2024/07/nathalie-2-scaled.jpeg') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(139, 60, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1920;s:6:"height";i:1158;s:4:"file";s:30:"2024/07/nathalie-2-scaled.jpeg";s:8:"filesize";i:551066;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-2-300x181.jpeg";s:5:"width";i:300;s:6:"height";i:181;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:21364;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-2-1024x617.jpeg";s:5:"width";i:1024;s:6:"height";i:617;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:200303;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-2-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:10553;}s:12:"medium_large";a:5:{s:4:"file";s:23:"nathalie-2-768x463.jpeg";s:5:"width";i:768;s:6:"height";i:463;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:119786;}s:9:"1536x1536";a:5:{s:4:"file";s:24:"nathalie-2-1536x926.jpeg";s:5:"width";i:1536;s:6:"height";i:926;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:401736;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-2-2048x1235.jpeg";s:5:"width";i:2048;s:6:"height";i:1235;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:651492;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-2.jpeg";}'),
(140, 61, '_wp_attached_file', '2024/07/nathalie-3-scaled.jpeg'),
(141, 61, '_wp_attachment_metadata', 'a:7:{s:5:"width";i:1280;s:6:"height";i:1920;s:4:"file";s:30:"2024/07/nathalie-3-scaled.jpeg";s:8:"filesize";i:149846;s:5:"sizes";a:6:{s:6:"medium";a:5:{s:4:"file";s:23:"nathalie-3-200x300.jpeg";s:5:"width";i:200;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:9992;}s:5:"large";a:5:{s:4:"file";s:24:"nathalie-3-683x1024.jpeg";s:5:"width";i:683;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:58782;}s:9:"thumbnail";a:5:{s:4:"file";s:23:"nathalie-3-150x150.jpeg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:4720;}s:12:"medium_large";a:5:{s:4:"file";s:24:"nathalie-3-768x1152.jpeg";s:5:"width";i:768;s:6:"height";i:1152;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:69066;}s:9:"1536x1536";a:5:{s:4:"file";s:25:"nathalie-3-1024x1536.jpeg";s:5:"width";i:1024;s:6:"height";i:1536;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:105813;}s:9:"2048x2048";a:5:{s:4:"file";s:25:"nathalie-3-1365x2048.jpeg";s:5:"width";i:1365;s:6:"height";i:2048;s:9:"mime-type";s:10:"image/jpeg";s:8:"filesize";i:166283;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}s:14:"original_image";s:15:"nathalie-3.jpeg";}'),
(145, 64, '_wp_attached_file', '2024/07/Contact.png'),
(146, 64, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:281;s:6:"height";i:49;s:4:"file";s:19:"2024/07/Contact.png";s:8:"filesize";i:3104;s:5:"sizes";a:1:{s:9:"thumbnail";a:5:{s:4:"file";s:18:"Contact-150x49.png";s:5:"width";i:150;s:6:"height";i:49;s:9:"mime-type";s:9:"image/png";s:8:"filesize";i:1951;}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(147, 67, '_edit_lock', '1720519221:1'),
(148, 67, '_thumbnail_id', '58'),
(149, 67, '_edit_last', '1'),
(150, 67, 'type', 'Argentique'),
(151, 67, '_type', 'field_6683f3962a846'),
(152, 67, 'reference', 'bf2385'),
(153, 67, '_reference', 'field_6683f4f9725e4'),
(154, 67, '_wp_page_template', 'templates/single.php'),
(155, 67, '_wp_old_date', '2024-07-09'),
(156, 68, '_edit_lock', '1720520056:1'),
(157, 68, '_thumbnail_id', '59'),
(158, 68, '_edit_last', '1'),
(159, 68, 'type', 'Argentique'),
(160, 68, '_type', 'field_6683f3962a846'),
(161, 68, 'reference', 'bf2386'),
(162, 68, '_reference', 'field_6683f4f9725e4'),
(163, 69, '_edit_lock', '1720615654:1'),
(164, 69, '_thumbnail_id', '60'),
(165, 69, '_edit_last', '1'),
(166, 69, 'type', 'Numérique'),
(167, 69, '_type', 'field_6683f3962a846'),
(168, 69, 'reference', 'bf2387'),
(169, 69, '_reference', 'field_6683f4f9725e4'),
(170, 70, '_edit_lock', '1720622609:1'),
(171, 70, '_thumbnail_id', '61'),
(172, 70, '_edit_last', '1'),
(173, 70, 'type', 'Argentique'),
(174, 70, '_type', 'field_6683f3962a846'),
(175, 70, 'reference', 'bf2388'),
(176, 70, '_reference', 'field_6683f4f9725e4'),
(177, 71, '_edit_lock', '1720520101:1'),
(178, 71, '_thumbnail_id', '47'),
(179, 71, '_edit_last', '1'),
(180, 71, 'type', 'Numérique'),
(181, 71, '_type', 'field_6683f3962a846'),
(182, 71, 'reference', 'bf2389'),
(183, 71, '_reference', 'field_6683f4f9725e4'),
(184, 72, '_edit_lock', '1720520114:1'),
(185, 72, '_thumbnail_id', '48'),
(186, 72, '_edit_last', '1'),
(187, 72, 'type', 'Numérique'),
(188, 72, '_type', 'field_6683f3962a846'),
(189, 72, 'reference', 'bf2390'),
(190, 72, '_reference', 'field_6683f4f9725e4'),
(191, 68, '_wp_page_template', 'templates/single.php'),
(192, 68, '_wp_old_slug', 'et-bon'),
(193, 68, '_wp_old_date', '2024-07-09'),
(194, 69, '_wp_page_template', 'templates/single.php'),
(195, 69, '_wp_old_date', '2024-07-09'),
(196, 70, '_wp_page_template', 'templates/single.php'),
(197, 70, '_wp_old_date', '2024-07-09'),
(198, 71, '_wp_page_template', 'templates/single.php'),
(199, 71, '_wp_old_date', '2024-07-09'),
(200, 72, '_wp_page_template', 'templates/single.php'),
(201, 72, '_wp_old_date', '2024-07-09'),
(202, 73, '_edit_lock', '1720520621:1'),
(203, 73, '_thumbnail_id', '49'),
(204, 73, '_edit_last', '1'),
(205, 73, 'type', 'Numérique'),
(206, 73, '_type', 'field_6683f3962a846'),
(207, 73, 'reference', 'bf2391'),
(208, 73, '_reference', 'field_6683f4f9725e4'),
(209, 74, '_edit_lock', '1720524419:1'),
(210, 73, '_wp_page_template', 'templates/single.php'),
(211, 73, '_wp_old_slug', 'dansons'),
(212, 73, '_wp_old_date', '2024-07-09'),
(213, 74, '_thumbnail_id', '50'),
(214, 74, '_edit_last', '1'),
(215, 74, 'type', 'Numérique'),
(216, 74, '_type', 'field_6683f3962a846'),
(217, 74, 'reference', 'bf2392'),
(218, 74, '_reference', 'field_6683f4f9725e4'),
(219, 75, '_edit_lock', '1720524434:1'),
(220, 75, '_thumbnail_id', '51'),
(221, 75, '_edit_last', '1'),
(222, 75, 'type', 'Numérique'),
(223, 75, '_type', 'field_6683f3962a846'),
(224, 75, 'reference', 'bf2393'),
(225, 75, '_reference', 'field_6683f4f9725e4'),
(226, 76, '_edit_lock', '1720524451:1'),
(227, 76, '_thumbnail_id', '52'),
(228, 76, '_edit_last', '1'),
(229, 76, 'type', 'Numérique'),
(230, 76, '_type', 'field_6683f3962a846'),
(231, 76, 'reference', 'bf2394'),
(232, 76, '_reference', 'field_6683f4f9725e4'),
(233, 77, '_edit_lock', '1720524463:1'),
(234, 77, '_thumbnail_id', '53'),
(235, 77, '_edit_last', '1'),
(236, 77, 'type', 'Numérique'),
(237, 77, '_type', 'field_6683f3962a846'),
(238, 77, 'reference', 'bf2395'),
(239, 77, '_reference', 'field_6683f4f9725e4'),
(240, 78, '_edit_lock', '1720524474:1'),
(241, 78, '_thumbnail_id', '54') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(242, 78, '_edit_last', '1'),
(243, 78, 'type', 'Numérique'),
(244, 78, '_type', 'field_6683f3962a846'),
(245, 78, 'reference', 'bf2397'),
(246, 78, '_reference', 'field_6683f4f9725e4'),
(247, 79, '_edit_lock', '1720524489:1'),
(248, 79, '_thumbnail_id', '55'),
(249, 79, '_edit_last', '1'),
(250, 79, 'type', 'Numérique'),
(251, 79, '_type', 'field_6683f3962a846'),
(252, 79, 'reference', 'bf2398'),
(253, 79, '_reference', 'field_6683f4f9725e4'),
(254, 80, '_edit_lock', '1720524501:1'),
(255, 80, '_thumbnail_id', '56'),
(256, 80, '_edit_last', '1'),
(257, 80, 'type', 'Argentique'),
(258, 80, '_type', 'field_6683f3962a846'),
(259, 80, 'reference', 'bf2399'),
(260, 80, '_reference', 'field_6683f4f9725e4'),
(261, 81, '_edit_lock', '1723025283:1'),
(262, 81, '_thumbnail_id', '57'),
(263, 81, '_edit_last', '1'),
(264, 81, 'type', 'Numérique'),
(265, 81, '_type', 'field_6683f3962a846'),
(266, 81, 'reference', 'bf2400'),
(267, 81, '_reference', 'field_6683f4f9725e4'),
(268, 74, '_wp_page_template', 'templates/single.php'),
(269, 74, '_wp_old_date', '2024-07-09'),
(270, 75, '_wp_page_template', 'templates/single.php'),
(271, 75, '_wp_old_date', '2024-07-09'),
(272, 76, '_wp_page_template', 'templates/single.php'),
(273, 76, '_wp_old_date', '2024-07-09'),
(274, 77, '_wp_page_template', 'templates/single.php'),
(275, 77, '_wp_old_date', '2024-07-09'),
(276, 78, '_wp_page_template', 'templates/single.php'),
(277, 78, '_wp_old_date', '2024-07-09'),
(278, 79, '_wp_page_template', 'templates/single.php'),
(279, 79, '_wp_old_date', '2024-07-09'),
(280, 80, '_wp_page_template', 'templates/single.php'),
(281, 80, '_wp_old_date', '2024-07-09'),
(282, 81, '_wp_page_template', 'templates/single.php'),
(283, 81, '_wp_old_date', '2024-07-09'),
(284, 83, '_wp_attached_file', '2024/07/Icon_eye.png'),
(285, 83, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:46;s:6:"height";i:32;s:4:"file";s:20:"2024/07/Icon_eye.png";s:8:"filesize";i:807;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(286, 84, '_wp_attached_file', '2024/07/Icon_fullscreen.png'),
(287, 84, '_wp_attachment_metadata', 'a:6:{s:5:"width";i:68;s:6:"height";i:68;s:4:"file";s:27:"2024/07/Icon_fullscreen.png";s:8:"filesize";i:807;s:5:"sizes";a:0:{}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(288, 85, '_menu_item_type', 'taxonomy'),
(289, 85, '_menu_item_menu_item_parent', '0'),
(290, 85, '_menu_item_object_id', '15'),
(291, 85, '_menu_item_object', 'categorie'),
(292, 85, '_menu_item_target', ''),
(293, 85, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(294, 85, '_menu_item_xfn', ''),
(295, 85, '_menu_item_url', ''),
(297, 86, '_menu_item_type', 'taxonomy'),
(298, 86, '_menu_item_menu_item_parent', '0'),
(299, 86, '_menu_item_object_id', '16'),
(300, 86, '_menu_item_object', 'categorie'),
(301, 86, '_menu_item_target', ''),
(302, 86, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(303, 86, '_menu_item_xfn', ''),
(304, 86, '_menu_item_url', ''),
(306, 87, '_menu_item_type', 'taxonomy'),
(307, 87, '_menu_item_menu_item_parent', '0'),
(308, 87, '_menu_item_object_id', '14'),
(309, 87, '_menu_item_object', 'categorie'),
(310, 87, '_menu_item_target', ''),
(311, 87, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(312, 87, '_menu_item_xfn', ''),
(313, 87, '_menu_item_url', ''),
(315, 88, '_menu_item_type', 'taxonomy'),
(316, 88, '_menu_item_menu_item_parent', '0'),
(317, 88, '_menu_item_object_id', '17'),
(318, 88, '_menu_item_object', 'categorie'),
(319, 88, '_menu_item_target', ''),
(320, 88, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(321, 88, '_menu_item_xfn', ''),
(322, 88, '_menu_item_url', ''),
(324, 89, '_acf_changed', ''),
(325, 89, 'footnotes', ''),
(326, 61, '_edit_lock', '1723024692:1'),
(327, 5, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.02;s:5:"bytes";i:88;s:7:"percent";d:3.54;s:11:"size_before";i:2488;s:10:"size_after";i:2400;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:2:{s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:77;s:7:"percent";d:3.55;s:11:"size_before";i:2171;s:10:"size_after";i:2094;}s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:11;s:7:"percent";d:3.47;s:11:"size_before";i:317;s:10:"size_after";i:306;}}}'),
(328, 8, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.36000000000000004;s:5:"bytes";i:90;s:7:"percent";d:0.01;s:11:"size_before";i:805674;s:10:"size_after";i:805584;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:90;s:7:"percent";d:1.18;s:11:"size_before";i:7628;s:10:"size_after";i:7538;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:15336;s:10:"size_after";i:15336;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.06;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:59680;s:10:"size_after";i:59680;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.07;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:89733;s:10:"size_after";i:89733;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.05;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:160800;s:10:"size_after";i:160800;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.08;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:248616;s:10:"size_after";i:248616;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.08;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:223881;s:10:"size_after";i:223881;}}}'),
(329, 47, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.55;s:5:"bytes";i:220;s:7:"percent";d:0.01;s:11:"size_before";i:1531000;s:10:"size_after";i:1530780;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:220;s:7:"percent";d:2.65;s:11:"size_before";i:8301;s:10:"size_after";i:8081;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.03;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:19120;s:10:"size_after";i:19120;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.08;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:154007;s:10:"size_after";i:154007;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.13;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:185149;s:10:"size_after";i:185149;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.08;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:293652;s:10:"size_after";i:293652;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.1;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:405064;s:10:"size_after";i:405064;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.11;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:465707;s:10:"size_after";i:465707;}}}'),
(330, 48, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.63;s:5:"bytes";i:266;s:7:"percent";d:0.02;s:11:"size_before";i:1665312;s:10:"size_after";i:1665046;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0;s:5:"bytes";i:262;s:7:"percent";d:2.98;s:11:"size_before";i:8796;s:10:"size_after";i:8534;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:4;s:7:"percent";d:0.02;s:11:"size_before";i:19961;s:10:"size_after";i:19957;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.12;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:190989;s:10:"size_after";i:190989;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.04;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:157234;s:10:"size_after";i:157234;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.1;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:314409;s:10:"size_after";i:314409;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.12;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:442954;s:10:"size_after";i:442954;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.23;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:530969;s:10:"size_after";i:530969;}}}'),
(331, 49, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.68;s:5:"bytes";i:16;s:7:"percent";d:0;s:11:"size_before";i:1311750;s:10:"size_after";i:1311734;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0;s:5:"bytes";i:15;s:7:"percent";d:0.24;s:11:"size_before";i:6182;s:10:"size_after";i:6167;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:1;s:7:"percent";d:0.01;s:11:"size_before";i:15227;s:10:"size_after";i:15226;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.03;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:70991;s:10:"size_after";i:70991;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.03;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:119012;s:10:"size_after";i:119012;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.21;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:257672;s:10:"size_after";i:257672;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.26;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:383266;s:10:"size_after";i:383266;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.14;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:459400;s:10:"size_after";i:459400;}}}'),
(332, 50, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.55;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:859034;s:10:"size_after";i:859034;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:6471;s:10:"size_after";i:6471;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:14142;s:10:"size_after";i:14142;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.06;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:93348;s:10:"size_after";i:93348;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:60109;s:10:"size_after";i:60109;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.15;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:172849;s:10:"size_after";i:172849;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.16;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:241524;s:10:"size_after";i:241524;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.14;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:270591;s:10:"size_after";i:270591;}}}'),
(333, 51, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.68;s:5:"bytes";i:317;s:7:"percent";d:0.03;s:11:"size_before";i:1057523;s:10:"size_after";i:1057206;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:316;s:7:"percent";d:3.46;s:11:"size_before";i:9130;s:10:"size_after";i:8814;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:17497;s:10:"size_after";i:17497;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.09;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:201564;s:10:"size_after";i:201564;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.17;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:277623;s:10:"size_after";i:277623;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.28;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:311207;s:10:"size_after";i:311207;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.08;s:5:"bytes";i:1;s:7:"percent";d:0;s:11:"size_before";i:130484;s:10:"size_after";i:130483;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.03;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:110018;s:10:"size_after";i:110018;}}}'),
(334, 52, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.47;s:5:"bytes";i:148;s:7:"percent";d:0.01;s:11:"size_before";i:1206375;s:10:"size_after";i:1206227;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:148;s:7:"percent";d:1.98;s:11:"size_before";i:7473;s:10:"size_after";i:7325;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.05;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:14940;s:10:"size_after";i:14940;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:71411;s:10:"size_after";i:71411;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.06;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:117812;s:10:"size_after";i:117812;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.14;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:345581;s:10:"size_after";i:345581;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.1;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:409691;s:10:"size_after";i:409691;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.09;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:239467;s:10:"size_after";i:239467;}}}'),
(335, 53, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.86;s:5:"bytes";i:151;s:7:"percent";d:0.01;s:11:"size_before";i:2760986;s:10:"size_after";i:2760835;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:9640;s:10:"size_after";i:9640;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:3;s:7:"percent";d:0.01;s:11:"size_before";i:27080;s:10:"size_after";i:27077;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.08;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:160205;s:10:"size_after";i:160205;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.31;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:932555;s:10:"size_after";i:932555;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.06;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:274903;s:10:"size_after";i:274903;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.28;s:5:"bytes";i:148;s:7:"percent";d:0.02;s:11:"size_before";i:785980;s:10:"size_after";i:785832;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.1;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:570623;s:10:"size_after";i:570623;}}}'),
(336, 54, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.54;s:5:"bytes";i:405;s:7:"percent";d:0.04;s:11:"size_before";i:1140337;s:10:"size_after";i:1139932;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:405;s:7:"percent";d:4.2;s:11:"size_before";i:9639;s:10:"size_after";i:9234;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:19079;s:10:"size_after";i:19079;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.03;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:81539;s:10:"size_after";i:81539;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.07;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:126466;s:10:"size_after";i:126466;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.14;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:230351;s:10:"size_after";i:230351;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.18;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:355826;s:10:"size_after";i:355826;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.1;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:317437;s:10:"size_after";i:317437;}}}'),
(337, 56, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.55;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:1025934;s:10:"size_after";i:1025934;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:11670;s:10:"size_after";i:11670;}s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:5583;s:10:"size_after";i:5583;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.03;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:97840;s:10:"size_after";i:97840;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.04;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:119233;s:10:"size_after";i:119233;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.23;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:195817;s:10:"size_after";i:195817;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.11;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:321282;s:10:"size_after";i:321282;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.11;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:274509;s:10:"size_after";i:274509;}}}'),
(338, 57, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.48;s:5:"bytes";i:76844;s:7:"percent";d:4.11;s:11:"size_before";i:1868263;s:10:"size_after";i:1791419;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0;s:5:"bytes";i:735;s:7:"percent";d:8.07;s:11:"size_before";i:9111;s:10:"size_after";i:8376;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:1620;s:7:"percent";d:7.57;s:11:"size_before";i:21406;s:10:"size_after";i:19786;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.11;s:5:"bytes";i:8521;s:7:"percent";d:5.25;s:11:"size_before";i:162353;s:10:"size_after";i:153832;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.04;s:5:"bytes";i:9574;s:7:"percent";d:4.91;s:11:"size_before";i:194862;s:10:"size_after";i:185288;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.06;s:5:"bytes";i:13802;s:7:"percent";d:4.45;s:11:"size_before";i:310272;s:10:"size_after";i:296470;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.1;s:5:"bytes";i:18919;s:7:"percent";d:3.91;s:11:"size_before";i:484463;s:10:"size_after";i:465544;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.16;s:5:"bytes";i:23673;s:7:"percent";d:3.45;s:11:"size_before";i:685796;s:10:"size_after";i:662123;}}}'),
(339, 58, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.4;s:5:"bytes";i:93;s:7:"percent";d:0.01;s:11:"size_before";i:797936;s:10:"size_after";i:797843;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:93;s:7:"percent";d:1.27;s:11:"size_before";i:7332;s:10:"size_after";i:7239;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:14686;s:10:"size_after";i:14686;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.05;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:86728;s:10:"size_after";i:86728;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.07;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:56932;s:10:"size_after";i:56932;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.11;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:158178;s:10:"size_after";i:158178;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.06;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:223228;s:10:"size_after";i:223228;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.09;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:250852;s:10:"size_after";i:250852;}}}'),
(340, 59, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.71;s:5:"bytes";i:202;s:7:"percent";d:0.02;s:11:"size_before";i:1305824;s:10:"size_after";i:1305622;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:202;s:7:"percent";d:2.35;s:11:"size_before";i:8613;s:10:"size_after";i:8411;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:19299;s:10:"size_after";i:19299;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:87873;s:10:"size_after";i:87873;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.03;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:138484;s:10:"size_after";i:138484;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.06;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:263799;s:10:"size_after";i:263799;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.11;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:421371;s:10:"size_after";i:421371;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.47;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:366385;s:10:"size_after";i:366385;}}}'),
(341, 60, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.8400000000000001;s:5:"bytes";i:1;s:7:"percent";d:0;s:11:"size_before";i:1956300;s:10:"size_after";i:1956299;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:1;s:7:"percent";d:0.01;s:11:"size_before";i:10553;s:10:"size_after";i:10552;}s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.04;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:21364;s:10:"size_after";i:21364;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.08;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:119786;s:10:"size_after";i:119786;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.04;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:200303;s:10:"size_after";i:200303;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.11;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:401736;s:10:"size_after";i:401736;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.19;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:551066;s:10:"size_after";i:551066;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.37;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:651492;s:10:"size_after";i:651492;}}}'),
(342, 61, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.49;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:564502;s:10:"size_after";i:564502;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:9992;s:10:"size_after";i:9992;}s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.02;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:4720;s:10:"size_after";i:4720;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.04;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:69066;s:10:"size_after";i:69066;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.07;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:58782;s:10:"size_after";i:58782;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.05;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:105813;s:10:"size_after";i:105813;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.08;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:166283;s:10:"size_after";i:166283;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.21;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:149846;s:10:"size_after";i:149846;}}}'),
(343, 64, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.04;s:5:"bytes";i:649;s:7:"percent";d:33.26;s:11:"size_before";i:1951;s:10:"size_after";i:1302;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:1:{s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.04;s:5:"bytes";i:649;s:7:"percent";d:33.26;s:11:"size_before";i:1951;s:10:"size_after";i:1302;}}}'),
(344, 55, 'wp-smpro-smush-data', 'a:2:{s:5:"stats";a:8:{s:4:"time";d:0.4;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:649560;s:10:"size_after";i:649560;s:5:"lossy";i:0;s:9:"keep_exif";i:0;s:11:"api_version";s:3:"1.0";}s:5:"sizes";a:7:{s:6:"medium";O:8:"stdClass":5:{s:4:"time";d:0.03;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:10566;s:10:"size_after";i:10566;}s:9:"thumbnail";O:8:"stdClass":5:{s:4:"time";d:0.01;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:5724;s:10:"size_after";i:5724;}s:5:"large";O:8:"stdClass":5:{s:4:"time";d:0.07;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:67140;s:10:"size_after";i:67140;}s:12:"medium_large";O:8:"stdClass":5:{s:4:"time";d:0.1;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:79879;s:10:"size_after";i:79879;}s:9:"1536x1536";O:8:"stdClass":5:{s:4:"time";d:0.04;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:122912;s:10:"size_after";i:122912;}s:9:"2048x2048";O:8:"stdClass":5:{s:4:"time";d:0.08;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:191523;s:10:"size_after";i:191523;}s:9:"wp_scaled";O:8:"stdClass":5:{s:4:"time";d:0.07;s:5:"bytes";i:0;s:7:"percent";i:0;s:11:"size_before";i:171816;s:10:"size_after";i:171816;}}}') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT 0,
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext NOT NULL,
  `post_title` text NOT NULL,
  `post_excerpt` text NOT NULL,
  `post_status` varchar(20) NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) NOT NULL DEFAULT 'open',
  `post_password` varchar(255) NOT NULL DEFAULT '',
  `post_name` varchar(200) NOT NULL DEFAULT '',
  `to_ping` text NOT NULL,
  `pinged` text NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `guid` varchar(255) NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT 0,
  `post_type` varchar(20) NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=92 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2024-06-26 11:23:11', '2024-06-26 09:23:11', '<!-- wp:paragraph -->\n<p>Bienvenue sur WordPress. Ceci est votre premier article. Modifiez-le ou supprimez-le, puis commencez à écrire !</p>\n<!-- /wp:paragraph -->', 'Bonjour tout le monde !', '', 'publish', 'open', 'open', '', 'bonjour-tout-le-monde', '', '', '2024-06-26 11:23:11', '2024-06-26 09:23:11', '', 0, 'https://localhost/mota/?p=1', 0, 'post', '', 1),
(2, 1, '2024-06-26 11:23:11', '2024-06-26 09:23:11', '<!-- wp:paragraph -->\n<p>Ceci est une page d’exemple. C’est différent d’un article de blog parce qu’elle restera au même endroit et apparaîtra dans la navigation de votre site (dans la plupart des thèmes). La plupart des gens commencent par une page « À propos » qui les présente aux personnes visitant le site. Cela pourrait ressembler à quelque chose comme cela :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>Bonjour ! Je suis un mécanicien qui aspire à devenir acteur, et voici mon site. J’habite à Bordeaux, j’ai un super chien baptisé Russell, et j’aime la vodka (ainsi qu’être surpris par la pluie soudaine lors de longues balades sur la plage au coucher du soleil).</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>…ou quelque chose comme cela :</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:quote -->\n<blockquote class="wp-block-quote"><p>La société 123 Machin Truc a été créée en 1971, et n’a cessé de proposer au public des machins-trucs de qualité depuis lors. Située à Saint-Remy-en-Bouzemont-Saint-Genest-et-Isson, 123 Machin Truc emploie 2 000 personnes, et fabrique toutes sortes de bidules supers pour la communauté bouzemontoise.</p></blockquote>\n<!-- /wp:quote -->\n\n<!-- wp:paragraph -->\n<p>En tant que nouvel utilisateur ou utilisatrice de WordPress, vous devriez vous rendre sur <a href="https://localhost/mota/wp-admin/">votre tableau de bord</a> pour supprimer cette page et créer de nouvelles pages pour votre contenu. Amusez-vous bien !</p>\n<!-- /wp:paragraph -->', 'Page d’exemple', '', 'publish', 'closed', 'open', '', 'page-d-exemple', '', '', '2024-06-26 11:23:11', '2024-06-26 09:23:11', '', 0, 'https://localhost/mota/?page_id=2', 0, 'page', '', 0),
(3, 1, '2024-06-26 11:23:11', '2024-06-26 09:23:11', '<!-- wp:heading {"level":1} -->\n<h1 class="wp-block-heading">Vie privée</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Qui sommes-nous&nbsp;?</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>L’adresse de notre site est&nbsp;: https://localhost/mota.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Commentaires</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Quand vous laissez un commentaire sur notre site, les données inscrites dans le formulaire de commentaire, ainsi que votre adresse IP et l’agent utilisateur de votre navigateur sont collectés pour nous aider à la détection des commentaires indésirables.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Une chaîne anonymisée créée à partir de votre adresse e-mail (également appelée hash) peut être envoyée au service Gravatar pour vérifier si vous utilisez ce dernier. Les clauses de confidentialité du service Gravatar sont disponibles ici&nbsp;: https://automattic.com/privacy/. Après validation de votre commentaire, votre photo de profil sera visible publiquement à coté de votre commentaire.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Médias</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Si vous téléversez des images sur le site, nous vous conseillons d’éviter de téléverser des images contenant des données EXIF de coordonnées GPS. Les personnes visitant votre site peuvent télécharger et extraire des données de localisation depuis ces images.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Si vous déposez un commentaire sur notre site, il vous sera proposé d’enregistrer votre nom, adresse e-mail et site dans des cookies. C’est uniquement pour votre confort afin de ne pas avoir à saisir ces informations si vous déposez un autre commentaire plus tard. Ces cookies expirent au bout d’un an.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Si vous vous rendez sur la page de connexion, un cookie temporaire sera créé afin de déterminer si votre navigateur accepte les cookies. Il ne contient pas de données personnelles et sera supprimé automatiquement à la fermeture de votre navigateur.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorsque vous vous connecterez, nous mettrons en place un certain nombre de cookies pour enregistrer vos informations de connexion et vos préférences d’écran. La durée de vie d’un cookie de connexion est de deux jours, celle d’un cookie d’option d’écran est d’un an. Si vous cochez «&nbsp;Se souvenir de moi&nbsp;», votre cookie de connexion sera conservé pendant deux semaines. Si vous vous déconnectez de votre compte, le cookie de connexion sera effacé.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>En modifiant ou en publiant une publication, un cookie supplémentaire sera enregistré dans votre navigateur. Ce cookie ne comprend aucune donnée personnelle. Il indique simplement l’ID de la publication que vous venez de modifier. Il expire au bout d’un jour.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Contenu embarqué depuis d’autres sites</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Les articles de ce site peuvent inclure des contenus intégrés (par exemple des vidéos, images, articles…). Le contenu intégré depuis d’autres sites se comporte de la même manière que si le visiteur se rendait sur cet autre site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ces sites web pourraient collecter des données sur vous, utiliser des cookies, embarquer des outils de suivis tiers, suivre vos interactions avec ces contenus embarqués si vous disposez d’un compte connecté sur leur site web.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Utilisation et transmission de vos données personnelles</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Si vous demandez une réinitialisation de votre mot de passe, votre adresse IP sera incluse dans l’e-mail de réinitialisation.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Durées de stockage de vos données</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Si vous laissez un commentaire, le commentaire et ses métadonnées sont conservés indéfiniment. Cela permet de reconnaître et approuver automatiquement les commentaires suivants au lieu de les laisser dans la file de modération.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Pour les comptes qui s’inscrivent sur notre site (le cas échéant), nous stockons également les données personnelles indiquées dans leur profil. Tous les comptes peuvent voir, modifier ou supprimer leurs informations personnelles à tout moment (à l’exception de leur identifiant). Les gestionnaires du site peuvent aussi voir et modifier ces informations.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Les droits que vous avez sur vos données</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Si vous avez un compte ou si vous avez laissé des commentaires sur le site, vous pouvez demander à recevoir un fichier contenant toutes les données personnelles que nous possédons à votre sujet, incluant celles que vous nous avez fournies. Vous pouvez également demander la suppression des données personnelles vous concernant. Cela ne prend pas en compte les données stockées à des fins administratives, légales ou pour des raisons de sécurité.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Où vos données sont envoyées</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Les commentaires des visiteurs peuvent être vérifiés à l’aide d’un service automatisé de détection des commentaires indésirables.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading"></h2>\n<!-- /wp:heading -->', 'Vie privée', '', 'publish', 'closed', 'open', '', 'politique-de-confidentialite', '', '', '2024-06-27 14:54:38', '2024-06-27 12:54:38', '', 0, 'https://localhost/mota/?page_id=3', 0, 'page', '', 0),
(5, 1, '2024-06-26 12:15:11', '2024-06-26 10:15:11', '', 'Logo', '', 'inherit', 'open', 'closed', '', 'logo', '', '', '2024-06-26 12:15:11', '2024-06-26 10:15:11', '', 0, 'https://localhost/mota/wp-content/uploads/2024/06/Logo.png', 0, 'attachment', 'image/png', 0),
(8, 1, '2024-06-26 13:48:47', '2024-06-26 11:48:47', '', 'nathalie-11', '', 'inherit', 'open', 'closed', '', 'nathalie-11', '', '', '2024-06-26 13:48:47', '2024-06-26 11:48:47', '', 0, 'https://localhost/mota/wp-content/uploads/2024/06/nathalie-11.jpeg', 0, 'attachment', 'image/jpeg', 0),
(13, 1, '2024-06-26 16:22:09', '2024-06-26 14:22:09', '<!-- wp:navigation-link {"className":" menu-item menu-item-type-post_type menu-item-object-page","description":"","id":"2","kind":"post-type","label":"Page d’exemple","opensInNewTab":false,"rel":null,"title":"","type":"page","url":"https://localhost/mota/?page_id=2"} /-->', 'Menu footer', '', 'publish', 'closed', 'closed', '', 'menu-footer', '', '', '2024-06-26 16:22:09', '2024-06-26 14:22:09', '', 0, 'https://localhost/mota/?p=13', 0, 'wp_navigation', '', 0),
(15, 1, '2024-06-27 08:58:44', '2024-06-27 06:58:44', '<!-- wp:shortcode -->\n<?php get_header();?>\n<!-- /wp:shortcode -->\n\n<!-- wp:code -->\n<pre class="wp-block-code"><code>&lt;?php get_header();?></code></pre>\n<!-- /wp:code -->', 'header contenu footer', '', 'publish', 'closed', 'closed', '', 'wp-custom-template-header-contenu-footer', '', '', '2024-06-27 09:50:26', '2024-06-27 07:50:26', '', 0, 'https://localhost/mota/?p=15', 0, 'wp_template', '', 0),
(16, 1, '2024-06-27 09:01:49', '2024-06-27 07:01:49', '', 'header contenu footer', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2024-06-27 09:01:49', '2024-06-27 07:01:49', '', 15, 'https://localhost/mota/?p=16', 0, 'revision', '', 0),
(17, 1, '2024-06-27 09:03:19', '2024-06-27 07:03:19', '<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground"} -->\n<p class="has-foreground-color has-text-color has-link-color"></p>\n<!-- /wp:paragraph -->', 'À propos', '', 'publish', 'closed', 'closed', '', 'a-propos', '', '', '2024-06-27 14:16:54', '2024-06-27 12:16:54', '', 0, 'https://localhost/mota/?page_id=17', 0, 'page', '', 0),
(18, 1, '2024-06-27 09:03:19', '2024-06-27 07:03:19', '', 'À propos', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2024-06-27 09:03:19', '2024-06-27 07:03:19', '', 17, 'https://localhost/mota/?p=18', 0, 'revision', '', 0),
(20, 1, '2024-06-27 09:48:24', '2024-06-27 07:48:24', '<!-- wp:shortcode -->\n<?php get_header();?>\n<!-- /wp:shortcode -->', 'header contenu footer', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2024-06-27 09:48:24', '2024-06-27 07:48:24', '', 15, 'https://localhost/mota/?p=20', 0, 'revision', '', 0),
(21, 1, '2024-06-27 09:50:26', '2024-06-27 07:50:26', '<!-- wp:shortcode -->\n<?php get_header();?>\n<!-- /wp:shortcode -->\n\n<!-- wp:code -->\n<pre class="wp-block-code"><code>&lt;?php get_header();?></code></pre>\n<!-- /wp:code -->', 'header contenu footer', '', 'inherit', 'closed', 'closed', '', '15-revision-v1', '', '', '2024-06-27 09:50:26', '2024-06-27 07:50:26', '', 15, 'https://localhost/mota/?p=21', 0, 'revision', '', 0),
(22, 1, '2024-06-27 09:53:58', '0000-00-00 00:00:00', 'Thank you for reading this post, don\'t forget to subscribe!', 'Display a message after the 1st paragraph of posts', '', 'draft', 'closed', 'closed', '', '', '', '', '2024-06-27 09:53:58', '0000-00-00 00:00:00', '', 0, 'https://localhost/mota/?post_type=wpcode&p=22', 0, 'wpcode', '', 0),
(23, 1, '2024-06-27 09:53:58', '0000-00-00 00:00:00', 'add_action(\'admin_init\', function () {\r\n    // Redirect any user trying to access comments page\r\n    global $pagenow;\r\n    \r\n    if ($pagenow === \'edit-comments.php\') {\r\n        wp_safe_redirect(admin_url());\r\n        exit;\r\n    }\r\n\r\n    // Remove comments metabox from dashboard\r\n    remove_meta_box(\'dashboard_recent_comments\', \'dashboard\', \'normal\');\r\n\r\n    // Disable support for comments and trackbacks in post types\r\n    foreach (get_post_types() as $post_type) {\r\n        if (post_type_supports($post_type, \'comments\')) {\r\n            remove_post_type_support($post_type, \'comments\');\r\n            remove_post_type_support($post_type, \'trackbacks\');\r\n        }\r\n    }\r\n});\r\n\r\n// Close comments on the front-end\r\nadd_filter(\'comments_open\', \'__return_false\', 20, 2);\r\nadd_filter(\'pings_open\', \'__return_false\', 20, 2);\r\n\r\n// Hide existing comments\r\nadd_filter(\'comments_array\', \'__return_empty_array\', 10, 2);\r\n\r\n// Remove comments page in menu\r\nadd_action(\'admin_menu\', function () {\r\n    remove_menu_page(\'edit-comments.php\');\r\n});\r\n\r\n// Remove comments links from admin bar\r\nadd_action(\'init\', function () {\r\n    if (is_admin_bar_showing()) {\r\n        remove_action(\'admin_bar_menu\', \'wp_admin_bar_comments_menu\', 60);\r\n    }\r\n});', 'Completely Disable Comments', '', 'draft', 'closed', 'closed', '', '', '', '', '2024-06-27 09:53:58', '0000-00-00 00:00:00', '', 0, 'https://localhost/mota/?post_type=wpcode&p=23', 0, 'wpcode', '', 0),
(24, 1, '2024-06-27 11:58:51', '2024-06-27 09:58:51', '<!-- wp:paragraph -->\n<p>wtf</p>\n<!-- /wp:paragraph -->', 'À propos', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2024-06-27 11:58:51', '2024-06-27 09:58:51', '', 17, 'https://localhost/mota/?p=24', 0, 'revision', '', 0),
(25, 1, '2024-06-27 11:59:45', '2024-06-27 09:59:45', '<!-- wp:paragraph -->\n<p>wtf</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>hello?</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'À propos', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2024-06-27 11:59:45', '2024-06-27 09:59:45', '', 17, 'https://localhost/mota/?p=25', 0, 'revision', '', 0),
(26, 1, '2024-06-27 15:26:07', '2024-06-27 10:01:44', ' ', '', '', 'publish', 'closed', 'closed', '', '26', '', '', '2024-06-27 15:26:07', '2024-06-27 13:26:07', '', 0, 'https://localhost/mota/?p=26', 2, 'nav_menu_item', '', 0),
(27, 1, '2024-06-27 12:02:51', '2024-06-27 10:02:51', '<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground"} -->\n<p class="has-foreground-color has-text-color has-link-color">wtf</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>hello?</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->', 'À propos', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2024-06-27 12:02:51', '2024-06-27 10:02:51', '', 17, 'https://localhost/mota/?p=27', 0, 'revision', '', 0),
(28, 1, '2024-06-27 14:04:15', '2024-06-27 12:04:15', '<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground"} -->\n<p class="has-foreground-color has-text-color has-link-color">wtf</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>hello?</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p></p>\n<!-- /wp:paragraph -->\n\n<!-- wp:code -->\n<pre class="wp-block-code"><code>hleafhazmlkkm</code></pre>\n<!-- /wp:code -->', 'À propos', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2024-06-27 14:04:15', '2024-06-27 12:04:15', '', 17, 'https://localhost/mota/?p=28', 0, 'revision', '', 0),
(29, 1, '2024-06-27 14:12:15', '2024-06-27 12:12:15', '<!-- wp:heading --><h2>Qui sommes-nous ?</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>L’adresse de notre site est : https://localhost/mota.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Commentaires</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Quand vous laissez un commentaire sur notre site, les données inscrites dans le formulaire de commentaire, ainsi que votre adresse IP et l’agent utilisateur de votre navigateur sont collectés pour nous aider à la détection des commentaires indésirables.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Une chaîne anonymisée créée à partir de votre adresse e-mail (également appelée hash) peut être envoyée au service Gravatar pour vérifier si vous utilisez ce dernier. Les clauses de confidentialité du service Gravatar sont disponibles ici : https://automattic.com/privacy/. Après validation de votre commentaire, votre photo de profil sera visible publiquement à coté de votre commentaire.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Médias</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Si vous téléversez des images sur le site, nous vous conseillons d’éviter de téléverser des images contenant des données EXIF de coordonnées GPS. Les personnes visitant votre site peuvent télécharger et extraire des données de localisation depuis ces images.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Si vous déposez un commentaire sur notre site, il vous sera proposé d’enregistrer votre nom, adresse e-mail et site dans des cookies. C’est uniquement pour votre confort afin de ne pas avoir à saisir ces informations si vous déposez un autre commentaire plus tard. Ces cookies expirent au bout d’un an.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Si vous vous rendez sur la page de connexion, un cookie temporaire sera créé afin de déterminer si votre navigateur accepte les cookies. Il ne contient pas de données personnelles et sera supprimé automatiquement à la fermeture de votre navigateur.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Lorsque vous vous connecterez, nous mettrons en place un certain nombre de cookies pour enregistrer vos informations de connexion et vos préférences d’écran. La durée de vie d’un cookie de connexion est de deux jours, celle d’un cookie d’option d’écran est d’un an. Si vous cochez « Se souvenir de moi », votre cookie de connexion sera conservé pendant deux semaines. Si vous vous déconnectez de votre compte, le cookie de connexion sera effacé.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>En modifiant ou en publiant une publication, un cookie supplémentaire sera enregistré dans votre navigateur. Ce cookie ne comprend aucune donnée personnelle. Il indique simplement l’ID de la publication que vous venez de modifier. Il expire au bout d’un jour.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Contenu embarqué depuis d’autres sites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Les articles de ce site peuvent inclure des contenus intégrés (par exemple des vidéos, images, articles…). Le contenu intégré depuis d’autres sites se comporte de la même manière que si le visiteur se rendait sur cet autre site.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Ces sites web pourraient collecter des données sur vous, utiliser des cookies, embarquer des outils de suivis tiers, suivre vos interactions avec ces contenus embarqués si vous disposez d’un compte connecté sur leur site web.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Utilisation et transmission de vos données personnelles</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Si vous demandez une réinitialisation de votre mot de passe, votre adresse IP sera incluse dans l’e-mail de réinitialisation.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Durées de stockage de vos données</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Si vous laissez un commentaire, le commentaire et ses métadonnées sont conservés indéfiniment. Cela permet de reconnaître et approuver automatiquement les commentaires suivants au lieu de les laisser dans la file de modération.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Pour les comptes qui s’inscrivent sur notre site (le cas échéant), nous stockons également les données personnelles indiquées dans leur profil. Tous les comptes peuvent voir, modifier ou supprimer leurs informations personnelles à tout moment (à l’exception de leur identifiant). Les gestionnaires du site peuvent aussi voir et modifier ces informations.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Les droits que vous avez sur vos données</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Si vous avez un compte ou si vous avez laissé des commentaires sur le site, vous pouvez demander à recevoir un fichier contenant toutes les données personnelles que nous possédons à votre sujet, incluant celles que vous nous avez fournies. Vous pouvez également demander la suppression des données personnelles vous concernant. Cela ne prend pas en compte les données stockées à des fins administratives, légales ou pour des raisons de sécurité.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Où vos données sont envoyées</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Les commentaires des visiteurs peuvent être vérifiés à l’aide d’un service automatisé de détection des commentaires indésirables.</p><!-- /wp:paragraph -->', 'Mentions légales', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2024-06-27 14:12:15', '2024-06-27 12:12:15', '', 3, 'https://localhost/mota/?p=29', 0, 'revision', '', 0),
(30, 1, '2024-06-27 14:16:54', '2024-06-27 12:16:54', '<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground"} -->\n<p class="has-foreground-color has-text-color has-link-color"></p>\n<!-- /wp:paragraph -->', 'À propos', '', 'inherit', 'closed', 'closed', '', '17-revision-v1', '', '', '2024-06-27 14:16:54', '2024-06-27 12:16:54', '', 17, 'https://localhost/mota/?p=30', 0, 'revision', '', 0),
(31, 1, '2024-06-27 14:22:41', '2024-06-27 12:22:41', '<!-- wp:heading --><h2>Qui sommes-nous ?</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>L’adresse de notre site est : https://localhost/mota.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Commentaires</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Quand vous laissez un commentaire sur notre site, les données inscrites dans le formulaire de commentaire, ainsi que votre adresse IP et l’agent utilisateur de votre navigateur sont collectés pour nous aider à la détection des commentaires indésirables.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Une chaîne anonymisée créée à partir de votre adresse e-mail (également appelée hash) peut être envoyée au service Gravatar pour vérifier si vous utilisez ce dernier. Les clauses de confidentialité du service Gravatar sont disponibles ici : https://automattic.com/privacy/. Après validation de votre commentaire, votre photo de profil sera visible publiquement à coté de votre commentaire.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Médias</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Si vous téléversez des images sur le site, nous vous conseillons d’éviter de téléverser des images contenant des données EXIF de coordonnées GPS. Les personnes visitant votre site peuvent télécharger et extraire des données de localisation depuis ces images.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Cookies</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Si vous déposez un commentaire sur notre site, il vous sera proposé d’enregistrer votre nom, adresse e-mail et site dans des cookies. C’est uniquement pour votre confort afin de ne pas avoir à saisir ces informations si vous déposez un autre commentaire plus tard. Ces cookies expirent au bout d’un an.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Si vous vous rendez sur la page de connexion, un cookie temporaire sera créé afin de déterminer si votre navigateur accepte les cookies. Il ne contient pas de données personnelles et sera supprimé automatiquement à la fermeture de votre navigateur.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Lorsque vous vous connecterez, nous mettrons en place un certain nombre de cookies pour enregistrer vos informations de connexion et vos préférences d’écran. La durée de vie d’un cookie de connexion est de deux jours, celle d’un cookie d’option d’écran est d’un an. Si vous cochez « Se souvenir de moi », votre cookie de connexion sera conservé pendant deux semaines. Si vous vous déconnectez de votre compte, le cookie de connexion sera effacé.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>En modifiant ou en publiant une publication, un cookie supplémentaire sera enregistré dans votre navigateur. Ce cookie ne comprend aucune donnée personnelle. Il indique simplement l’ID de la publication que vous venez de modifier. Il expire au bout d’un jour.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Contenu embarqué depuis d’autres sites</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Les articles de ce site peuvent inclure des contenus intégrés (par exemple des vidéos, images, articles…). Le contenu intégré depuis d’autres sites se comporte de la même manière que si le visiteur se rendait sur cet autre site.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Ces sites web pourraient collecter des données sur vous, utiliser des cookies, embarquer des outils de suivis tiers, suivre vos interactions avec ces contenus embarqués si vous disposez d’un compte connecté sur leur site web.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Utilisation et transmission de vos données personnelles</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Si vous demandez une réinitialisation de votre mot de passe, votre adresse IP sera incluse dans l’e-mail de réinitialisation.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Durées de stockage de vos données</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Si vous laissez un commentaire, le commentaire et ses métadonnées sont conservés indéfiniment. Cela permet de reconnaître et approuver automatiquement les commentaires suivants au lieu de les laisser dans la file de modération.</p><!-- /wp:paragraph --><!-- wp:paragraph --><p>Pour les comptes qui s’inscrivent sur notre site (le cas échéant), nous stockons également les données personnelles indiquées dans leur profil. Tous les comptes peuvent voir, modifier ou supprimer leurs informations personnelles à tout moment (à l’exception de leur identifiant). Les gestionnaires du site peuvent aussi voir et modifier ces informations.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Les droits que vous avez sur vos données</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Si vous avez un compte ou si vous avez laissé des commentaires sur le site, vous pouvez demander à recevoir un fichier contenant toutes les données personnelles que nous possédons à votre sujet, incluant celles que vous nous avez fournies. Vous pouvez également demander la suppression des données personnelles vous concernant. Cela ne prend pas en compte les données stockées à des fins administratives, légales ou pour des raisons de sécurité.</p><!-- /wp:paragraph --><!-- wp:heading --><h2>Où vos données sont envoyées</h2><!-- /wp:heading --><!-- wp:paragraph --><p><strong class="privacy-policy-tutorial">Texte suggéré : </strong>Les commentaires des visiteurs peuvent être vérifiés à l’aide d’un service automatisé de détection des commentaires indésirables.</p><!-- /wp:paragraph -->', 'Vie privée', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2024-06-27 14:22:41', '2024-06-27 12:22:41', '', 3, 'https://localhost/mota/?p=31', 0, 'revision', '', 0),
(32, 1, '2024-06-27 14:23:10', '2024-06-27 12:23:10', '', 'Mentions légales', '', 'publish', 'closed', 'closed', '', 'mentions-legales', '', '', '2024-06-27 14:23:10', '2024-06-27 12:23:10', '', 0, 'https://localhost/mota/?page_id=32', 0, 'page', '', 0),
(33, 1, '2024-06-27 14:23:10', '2024-06-27 12:23:10', '', 'Mentions légales', '', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2024-06-27 14:23:10', '2024-06-27 12:23:10', '', 32, 'https://localhost/mota/?p=33', 0, 'revision', '', 0),
(34, 1, '2024-06-27 14:24:46', '2024-06-27 12:24:46', ' ', '', '', 'publish', 'closed', 'closed', '', '34', '', '', '2024-06-27 14:24:46', '2024-06-27 12:24:46', '', 0, 'https://localhost/mota/?p=34', 2, 'nav_menu_item', '', 0),
(35, 1, '2024-06-27 14:24:46', '2024-06-27 12:24:46', ' ', '', '', 'publish', 'closed', 'closed', '', '35', '', '', '2024-06-27 14:24:46', '2024-06-27 12:24:46', '', 0, 'https://localhost/mota/?p=35', 1, 'nav_menu_item', '', 0),
(36, 1, '2024-06-27 14:31:30', '2024-06-27 12:31:30', '', 'Accueil', '', 'publish', 'closed', 'closed', '', 'accueil', '', '', '2024-06-27 14:31:30', '2024-06-27 12:31:30', '', 0, 'https://localhost/mota/?page_id=36', 0, 'page', '', 0),
(37, 1, '2024-06-27 14:31:30', '2024-06-27 12:31:30', '', 'Accueil', '', 'inherit', 'closed', 'closed', '', '36-revision-v1', '', '', '2024-06-27 14:31:30', '2024-06-27 12:31:30', '', 36, 'https://localhost/mota/?p=37', 0, 'revision', '', 0),
(38, 1, '2024-06-27 14:54:38', '2024-06-27 12:54:38', '<!-- wp:heading {"level":1} -->\n<h1 class="wp-block-heading">Vie privée</h1>\n<!-- /wp:heading -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Qui sommes-nous&nbsp;?</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>L’adresse de notre site est&nbsp;: https://localhost/mota.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Commentaires</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Quand vous laissez un commentaire sur notre site, les données inscrites dans le formulaire de commentaire, ainsi que votre adresse IP et l’agent utilisateur de votre navigateur sont collectés pour nous aider à la détection des commentaires indésirables.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Une chaîne anonymisée créée à partir de votre adresse e-mail (également appelée hash) peut être envoyée au service Gravatar pour vérifier si vous utilisez ce dernier. Les clauses de confidentialité du service Gravatar sont disponibles ici&nbsp;: https://automattic.com/privacy/. Après validation de votre commentaire, votre photo de profil sera visible publiquement à coté de votre commentaire.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Médias</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Si vous téléversez des images sur le site, nous vous conseillons d’éviter de téléverser des images contenant des données EXIF de coordonnées GPS. Les personnes visitant votre site peuvent télécharger et extraire des données de localisation depuis ces images.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Cookies</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Si vous déposez un commentaire sur notre site, il vous sera proposé d’enregistrer votre nom, adresse e-mail et site dans des cookies. C’est uniquement pour votre confort afin de ne pas avoir à saisir ces informations si vous déposez un autre commentaire plus tard. Ces cookies expirent au bout d’un an.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Si vous vous rendez sur la page de connexion, un cookie temporaire sera créé afin de déterminer si votre navigateur accepte les cookies. Il ne contient pas de données personnelles et sera supprimé automatiquement à la fermeture de votre navigateur.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Lorsque vous vous connecterez, nous mettrons en place un certain nombre de cookies pour enregistrer vos informations de connexion et vos préférences d’écran. La durée de vie d’un cookie de connexion est de deux jours, celle d’un cookie d’option d’écran est d’un an. Si vous cochez «&nbsp;Se souvenir de moi&nbsp;», votre cookie de connexion sera conservé pendant deux semaines. Si vous vous déconnectez de votre compte, le cookie de connexion sera effacé.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>En modifiant ou en publiant une publication, un cookie supplémentaire sera enregistré dans votre navigateur. Ce cookie ne comprend aucune donnée personnelle. Il indique simplement l’ID de la publication que vous venez de modifier. Il expire au bout d’un jour.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Contenu embarqué depuis d’autres sites</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Les articles de ce site peuvent inclure des contenus intégrés (par exemple des vidéos, images, articles…). Le contenu intégré depuis d’autres sites se comporte de la même manière que si le visiteur se rendait sur cet autre site.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Ces sites web pourraient collecter des données sur vous, utiliser des cookies, embarquer des outils de suivis tiers, suivre vos interactions avec ces contenus embarqués si vous disposez d’un compte connecté sur leur site web.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Utilisation et transmission de vos données personnelles</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Si vous demandez une réinitialisation de votre mot de passe, votre adresse IP sera incluse dans l’e-mail de réinitialisation.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Durées de stockage de vos données</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Si vous laissez un commentaire, le commentaire et ses métadonnées sont conservés indéfiniment. Cela permet de reconnaître et approuver automatiquement les commentaires suivants au lieu de les laisser dans la file de modération.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:paragraph -->\n<p>Pour les comptes qui s’inscrivent sur notre site (le cas échéant), nous stockons également les données personnelles indiquées dans leur profil. Tous les comptes peuvent voir, modifier ou supprimer leurs informations personnelles à tout moment (à l’exception de leur identifiant). Les gestionnaires du site peuvent aussi voir et modifier ces informations.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Les droits que vous avez sur vos données</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Si vous avez un compte ou si vous avez laissé des commentaires sur le site, vous pouvez demander à recevoir un fichier contenant toutes les données personnelles que nous possédons à votre sujet, incluant celles que vous nous avez fournies. Vous pouvez également demander la suppression des données personnelles vous concernant. Cela ne prend pas en compte les données stockées à des fins administratives, légales ou pour des raisons de sécurité.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading">Où vos données sont envoyées</h2>\n<!-- /wp:heading -->\n\n<!-- wp:paragraph -->\n<p><strong class="privacy-policy-tutorial">Texte suggéré&nbsp;: </strong>Les commentaires des visiteurs peuvent être vérifiés à l’aide d’un service automatisé de détection des commentaires indésirables.</p>\n<!-- /wp:paragraph -->\n\n<!-- wp:heading -->\n<h2 class="wp-block-heading"></h2>\n<!-- /wp:heading -->', 'Vie privée', '', 'inherit', 'closed', 'closed', '', '3-revision-v1', '', '', '2024-06-27 14:54:38', '2024-06-27 12:54:38', '', 3, 'https://localhost/mota/?p=38', 0, 'revision', '', 0),
(39, 1, '2024-06-27 15:26:07', '2024-06-27 13:07:55', ' ', '', '', 'publish', 'closed', 'closed', '', '39', '', '', '2024-06-27 15:26:07', '2024-06-27 13:26:07', '', 0, 'https://localhost/mota/?p=39', 1, 'nav_menu_item', '', 0),
(40, 1, '2024-06-28 11:55:25', '2024-06-28 09:55:25', '<label> Your name\n    [text* your-name autocomplete:name] </label>\n\n<label> Your email\n    [email* your-email autocomplete:email] </label>\n\n<label> Subject\n    [text* your-subject] </label>\n\n<label> Your message (optional)\n    [textarea your-message] </label>\n\n[submit "Submit"]\n[_site_title] "[your-subject]"\n[_site_title] <erchluprev@gmail.com>\nFrom: [your-name] [your-email]\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n-- \nThis is a notification that a contact form was submitted on your website ([_site_title] [_site_url]).\n[_site_admin_email]\nReply-To: [your-email]\n\n0\n0\n\n[_site_title] "[your-subject]"\n[_site_title] <erchluprev@gmail.com>\nMessage Body:\n[your-message]\n\n-- \nThis email is a receipt for your contact form submission on our website ([_site_title] [_site_url]) in which your email address was used. If that was not you, please ignore this message.\n[your-email]\nReply-To: [_site_admin_email]\n\n0\n0\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nPlease fill out this field.\nThis field has a too long input.\nThis field has a too short input.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe uploaded file is too large.\nThere was an error uploading the file.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2024-06-28 11:55:25', '2024-06-28 09:55:25', '', 0, 'https://localhost/mota/?post_type=wpcf7_contact_form&p=40', 0, 'wpcf7_contact_form', '', 0),
(41, 1, '2024-06-28 11:58:39', '2024-06-28 09:58:39', '<label> NOM </label>\r\n    [text* your-name autocomplete:name]\r\n\r\n<label> E-MAIL\r\n    [email* your-email autocomplete:email] </label>\r\n\r\n<label id="modale-ref-photo" value="hein?"> RÉF. PHOTO (optional)\r\n    [text* your-subject] </label>\r\n\r\n<label> MESSAGE\r\n    [textarea your-message] </label>\r\n\r\n[submit "Envoyer"]\n1\n[_site_title] "[your-subject]"\n[_site_title] <erchluprev@gmail.com>\n[_site_admin_email]\nFrom: [your-name] [your-email]\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis is a notification that a contact form was submitted on your website ([_site_title] [_site_url]).\nReply-To: [your-email]\n\n\n\n\n[_site_title] "[your-subject]"\n[_site_title] <erchluprev@gmail.com>\n[your-email]\nMessage Body:\r\n[your-message]\r\n\r\n-- \r\nThis email is a receipt for your contact form submission on our website ([_site_title] [_site_url]) in which your email address was used. If that was not you, please ignore this message.\nReply-To: [_site_admin_email]\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nPlease fill out this field.\nThis field has a too long input.\nThis field has a too short input.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe uploaded file is too large.\nThere was an error uploading the file.\nPlease enter a date in YYYY-MM-DD format.\nThis field has a too early date.\nThis field has a too late date.\nPlease enter a number.\nThis field has a too small number.\nThis field has a too large number.\nThe answer to the quiz is incorrect.\nPlease enter an email address.\nPlease enter a URL.\nPlease enter a telephone number.', 'modale contact', '', 'publish', 'closed', 'closed', '', 'modale-contact', '', '', '2024-07-09 14:00:33', '2024-07-09 12:00:33', '', 0, 'https://localhost/mota/?post_type=wpcf7_contact_form&#038;p=41', 0, 'wpcf7_contact_form', '', 0),
(42, 1, '2024-07-02 14:38:52', '2024-07-02 12:38:52', 'a:8:{s:8:"location";a:1:{i:0;a:1:{i:0;a:3:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:5:"photo";}}}s:8:"position";s:6:"normal";s:5:"style";s:7:"default";s:15:"label_placement";s:3:"top";s:21:"instruction_placement";s:5:"label";s:14:"hide_on_screen";s:0:"";s:11:"description";s:0:"";s:12:"show_in_rest";i:0;}', 'Type', 'type', 'publish', 'closed', 'closed', '', 'group_6683f395428b1', '', '', '2024-07-02 14:40:14', '2024-07-02 12:40:14', '', 0, 'https://localhost/mota/?post_type=acf-field-group&#038;p=42', 0, 'acf-field-group', '', 0),
(43, 1, '2024-07-02 14:38:52', '2024-07-02 12:38:52', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:24:"Argentique ou numérique";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:10:"Argentique";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Type', 'type', 'publish', 'closed', 'closed', '', 'field_6683f3962a846', '', '', '2024-07-02 14:38:52', '2024-07-02 12:38:52', '', 42, 'https://localhost/mota/?post_type=acf-field&p=43', 0, 'acf-field', '', 0),
(45, 1, '2024-07-02 14:39:59', '2024-07-02 12:39:59', 'a:11:{s:10:"aria-label";s:0:"";s:4:"type";s:4:"text";s:12:"instructions";s:0:"";s:8:"required";i:1;s:17:"conditional_logic";i:0;s:7:"wrapper";a:3:{s:5:"width";s:0:"";s:5:"class";s:0:"";s:2:"id";s:0:"";}s:13:"default_value";s:6:"bf0000";s:9:"maxlength";s:0:"";s:11:"placeholder";s:0:"";s:7:"prepend";s:0:"";s:6:"append";s:0:"";}', 'Référence', 'reference', 'publish', 'closed', 'closed', '', 'field_6683f4f9725e4', '', '', '2024-07-02 14:40:14', '2024-07-02 12:40:14', '', 42, 'https://localhost/mota/?post_type=acf-field&#038;p=45', 1, 'acf-field', '', 0),
(46, 1, '2022-07-02 14:44:56', '2022-07-02 12:44:56', '<!-- wp:image {"id":8,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/06/nathalie-11-1024x684.jpeg" alt="" class="wp-image-8"/></figure>\n<!-- /wp:image -->', 'Préparation', '', 'publish', 'closed', 'closed', '', 'preparation', '', '', '2024-07-04 13:49:43', '2024-07-04 11:49:43', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=46', 0, 'photo', '', 0),
(47, 1, '2024-07-02 14:53:32', '2024-07-02 12:53:32', '', 'nathalie-4', '', 'inherit', 'open', 'closed', '', 'nathalie-4', '', '', '2024-07-02 14:53:32', '2024-07-02 12:53:32', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-4.jpeg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2024-07-02 14:53:49', '2024-07-02 12:53:49', '', 'nathalie-5', '', 'inherit', 'open', 'closed', '', 'nathalie-5', '', '', '2024-07-02 14:53:49', '2024-07-02 12:53:49', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-5.jpeg', 0, 'attachment', 'image/jpeg', 0),
(49, 1, '2024-07-02 14:54:10', '2024-07-02 12:54:10', '', 'nathalie-6', '', 'inherit', 'open', 'closed', '', 'nathalie-6', '', '', '2024-07-02 14:54:10', '2024-07-02 12:54:10', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-6.jpeg', 0, 'attachment', 'image/jpeg', 0),
(50, 1, '2024-07-02 14:54:29', '2024-07-02 12:54:29', '', 'nathalie-7', '', 'inherit', 'open', 'closed', '', 'nathalie-7', '', '', '2024-07-02 14:54:29', '2024-07-02 12:54:29', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-7.jpeg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2024-07-02 14:54:42', '2024-07-02 12:54:42', '', 'nathalie-8', '', 'inherit', 'open', 'closed', '', 'nathalie-8', '', '', '2024-07-02 14:54:42', '2024-07-02 12:54:42', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-8.jpeg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2024-07-02 14:55:02', '2024-07-02 12:55:02', '', 'nathalie-9', '', 'inherit', 'open', 'closed', '', 'nathalie-9', '', '', '2024-07-02 14:55:02', '2024-07-02 12:55:02', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-9.jpeg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2024-07-02 14:55:20', '2024-07-02 12:55:20', '', 'nathalie-10', '', 'inherit', 'open', 'closed', '', 'nathalie-10', '', '', '2024-07-02 14:55:20', '2024-07-02 12:55:20', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-10.jpeg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2024-07-02 14:55:36', '2024-07-02 12:55:36', '', 'nathalie-12', '', 'inherit', 'open', 'closed', '', 'nathalie-12', '', '', '2024-07-02 14:55:36', '2024-07-02 12:55:36', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-12.jpeg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2024-07-02 14:55:58', '2024-07-02 12:55:58', '', 'nathalie-13', '', 'inherit', 'open', 'closed', '', 'nathalie-13', '', '', '2024-07-02 14:55:58', '2024-07-02 12:55:58', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-13.jpeg', 0, 'attachment', 'image/jpeg', 0),
(56, 1, '2024-07-02 14:56:21', '2024-07-02 12:56:21', '', 'nathalie-14', '', 'inherit', 'open', 'closed', '', 'nathalie-14', '', '', '2024-07-02 14:56:21', '2024-07-02 12:56:21', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-14.jpeg', 0, 'attachment', 'image/jpeg', 0),
(57, 1, '2024-07-02 14:56:44', '2024-07-02 12:56:44', '', 'nathalie-15', '', 'inherit', 'open', 'closed', '', 'nathalie-15', '', '', '2024-07-02 14:56:44', '2024-07-02 12:56:44', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-15.jpeg', 0, 'attachment', 'image/jpeg', 0),
(58, 1, '2024-07-02 14:57:10', '2024-07-02 12:57:10', '', 'nathalie-0', '', 'inherit', 'open', 'closed', '', 'nathalie-0', '', '', '2024-07-02 14:57:10', '2024-07-02 12:57:10', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-0.jpeg', 0, 'attachment', 'image/jpeg', 0),
(59, 1, '2024-07-02 14:57:34', '2024-07-02 12:57:34', '', 'nathalie-1', '', 'inherit', 'open', 'closed', '', 'nathalie-1', '', '', '2024-07-02 14:57:34', '2024-07-02 12:57:34', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-1.jpeg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2024-07-02 14:57:59', '2024-07-02 12:57:59', '', 'nathalie-2', '', 'inherit', 'open', 'closed', '', 'nathalie-2', '', '', '2024-07-02 14:57:59', '2024-07-02 12:57:59', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-2.jpeg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2024-07-02 14:58:08', '2024-07-02 12:58:08', '', 'nathalie-3', '', 'inherit', 'open', 'closed', '', 'nathalie-3', '', '', '2024-07-02 14:58:08', '2024-07-02 12:58:08', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/nathalie-3.jpeg', 0, 'attachment', 'image/jpeg', 0),
(64, 1, '2024-07-03 14:48:57', '2024-07-03 12:48:57', '', 'Contact', '', 'inherit', 'open', 'closed', '', 'contact', '', '', '2024-07-03 14:48:57', '2024-07-03 12:48:57', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/Contact.png', 0, 'attachment', 'image/png', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(67, 1, '2019-07-09 11:59:04', '2019-07-09 09:59:04', '<!-- wp:image {"id":58,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-0-1024x683.jpeg" alt="" class="wp-image-58"/></figure>\n<!-- /wp:image -->', 'Santé !', '', 'publish', 'closed', 'closed', '', 'sante', '', '', '2024-07-09 12:00:20', '2024-07-09 10:00:20', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=67', 0, 'photo', '', 0),
(68, 1, '2020-07-09 12:03:12', '2020-07-09 10:03:12', '<!-- wp:image {"id":59,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-1-1024x683.jpeg" alt="" class="wp-image-59"/></figure>\n<!-- /wp:image -->', 'Et bon anniversaire', '', 'publish', 'closed', 'closed', '', 'et-bon-anniversaire', '', '', '2024-07-09 12:14:16', '2024-07-09 10:14:16', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=68', 0, 'photo', '', 0),
(69, 1, '2021-07-09 12:04:42', '2021-07-09 10:04:42', '<!-- wp:image {"id":60,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-2-1024x617.jpeg" alt="" class="wp-image-60"/></figure>\n<!-- /wp:image -->', 'Let\'s party!', '', 'publish', 'closed', 'closed', '', 'lets-party', '', '', '2024-07-10 14:46:44', '2024-07-10 12:46:44', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=69', 0, 'photo', '', 0),
(70, 1, '2019-07-09 12:06:22', '2019-07-09 10:06:22', '<!-- wp:image {"id":61,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-3-683x1024.jpeg" alt="" class="wp-image-61"/></figure>\n<!-- /wp:image -->', 'Tout est installé', '', 'publish', 'closed', 'closed', '', 'tout-est-installe', '', '', '2024-07-10 16:43:27', '2024-07-10 14:43:27', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=70', 0, 'photo', '', 0),
(71, 1, '2020-07-09 12:10:14', '2020-07-09 10:10:14', '<!-- wp:image {"id":47,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-4-683x1024.jpeg" alt="" class="wp-image-47"/></figure>\n<!-- /wp:image -->', 'Vers l\'éternité', '', 'publish', 'closed', 'closed', '', 'vers-leternite', '', '', '2024-07-09 12:15:01', '2024-07-09 10:15:01', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=71', 0, 'photo', '', 0),
(72, 1, '2021-07-09 12:12:44', '2021-07-09 10:12:44', '<!-- wp:image {"id":48,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-5-683x1024.jpeg" alt="" class="wp-image-48"/></figure>\n<!-- /wp:image -->', 'Embrassez la mariée', '', 'publish', 'closed', 'closed', '', 'embrassez-la-mariee', '', '', '2024-07-09 12:15:14', '2024-07-09 10:15:14', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=72', 0, 'photo', '', 0),
(73, 1, '2020-07-09 12:22:21', '2020-07-09 10:22:21', '<!-- wp:image {"id":49,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-6-1024x819.jpeg" alt="" class="wp-image-49"/></figure>\n<!-- /wp:image -->', 'Dansons ensemble', '', 'publish', 'closed', 'closed', '', 'dansons-ensemble', '', '', '2024-07-09 12:23:41', '2024-07-09 10:23:41', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=73', 0, 'photo', '', 0),
(74, 1, '2019-07-09 12:25:56', '2019-07-09 10:25:56', '<!-- wp:image {"id":50,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-7-1024x683.jpeg" alt="" class="wp-image-50"/></figure>\n<!-- /wp:image -->', 'Le menu', '', 'publish', 'closed', 'closed', '', 'le-menu', '', '', '2024-07-09 13:26:59', '2024-07-09 11:26:59', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=74', 0, 'photo', '', 0),
(75, 1, '2021-07-09 12:27:27', '2021-07-09 10:27:27', '<!-- wp:image {"id":51,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-8-684x1024.jpeg" alt="" class="wp-image-51"/></figure>\n<!-- /wp:image -->', 'Au bal masqué', '', 'publish', 'closed', 'closed', '', 'au-bal-masque', '', '', '2024-07-09 13:27:14', '2024-07-09 11:27:14', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=75', 0, 'photo', '', 0),
(76, 1, '2022-07-09 12:29:03', '2022-07-09 10:29:03', '<!-- wp:image {"id":52,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-9-1024x683.jpeg" alt="" class="wp-image-52"/></figure>\n<!-- /wp:image -->', 'Let\'s dance!', '', 'publish', 'closed', 'closed', '', 'lets-dance', '', '', '2024-07-09 13:27:31', '2024-07-09 11:27:31', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=76', 0, 'photo', '', 0),
(77, 1, '2022-07-09 13:19:36', '2022-07-09 11:19:36', '<!-- wp:image {"id":53,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-10-1024x768.jpeg" alt="" class="wp-image-53"/></figure>\n<!-- /wp:image -->', 'Jour de match', '', 'publish', 'closed', 'closed', '', 'jour-de-match', '', '', '2024-07-09 13:27:43', '2024-07-09 11:27:43', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=77', 0, 'photo', '', 0),
(78, 1, '2022-07-09 13:21:40', '2022-07-09 11:21:40', '<!-- wp:image {"id":54,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-12-1024x683.jpeg" alt="" class="wp-image-54"/></figure>\n<!-- /wp:image -->', 'Bière ou eau plate ?', '', 'publish', 'closed', 'closed', '', 'biere-ou-eau-plate', '', '', '2024-07-09 13:27:54', '2024-07-09 11:27:54', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=78', 0, 'photo', '', 0),
(79, 1, '2022-07-09 13:23:03', '2022-07-09 11:23:03', '<!-- wp:image {"id":55,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-13-683x1024.jpeg" alt="" class="wp-image-55"/></figure>\n<!-- /wp:image -->', 'Bouquet final', '', 'publish', 'closed', 'closed', '', 'bouquet-final', '', '', '2024-07-09 13:28:09', '2024-07-09 11:28:09', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=79', 0, 'photo', '', 0),
(80, 1, '2022-07-09 13:24:14', '2022-07-09 11:24:14', '<!-- wp:image {"id":56,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-14-683x1024.jpeg" alt="" class="wp-image-56"/></figure>\n<!-- /wp:image -->', 'Du soir au matin', '', 'publish', 'closed', 'closed', '', 'du-soir-au-matin', '', '', '2024-07-09 13:28:21', '2024-07-09 11:28:21', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=80', 0, 'photo', '', 0),
(81, 1, '2022-07-09 13:25:50', '2022-07-09 11:25:50', '<!-- wp:image {"id":57,"sizeSlug":"large","linkDestination":"none"} -->\n<figure class="wp-block-image size-large"><img src="https://localhost/mota/wp-content/uploads/2024/07/nathalie-15-684x1024.jpeg" alt="" class="wp-image-57"/></figure>\n<!-- /wp:image -->', 'Team mariée', '', 'publish', 'closed', 'closed', '', 'team-mariee', '', '', '2024-08-07 12:03:09', '2024-08-07 10:03:09', '', 0, 'https://localhost/mota/?post_type=photo&#038;p=81', 0, 'photo', '', 0),
(83, 1, '2024-07-15 14:01:12', '2024-07-15 12:01:12', '', 'Icon_eye', '', 'inherit', 'open', 'closed', '', 'icon_eye', '', '', '2024-07-15 14:01:12', '2024-07-15 12:01:12', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/Icon_eye.png', 0, 'attachment', 'image/png', 0),
(84, 1, '2024-07-15 14:01:14', '2024-07-15 12:01:14', '', 'Icon_fullscreen', '', 'inherit', 'open', 'closed', '', 'icon_fullscreen', '', '', '2024-07-15 14:01:14', '2024-07-15 12:01:14', '', 0, 'https://localhost/mota/wp-content/uploads/2024/07/Icon_fullscreen.png', 0, 'attachment', 'image/png', 0),
(85, 1, '2024-07-16 12:05:51', '2024-07-16 10:05:51', ' ', '', '', 'publish', 'closed', 'closed', '', '85', '', '', '2024-07-16 12:05:51', '2024-07-16 10:05:51', '', 0, 'https://localhost/mota/?p=85', 1, 'nav_menu_item', '', 0),
(86, 1, '2024-07-16 12:05:51', '2024-07-16 10:05:51', ' ', '', '', 'publish', 'closed', 'closed', '', '86', '', '', '2024-07-16 12:05:51', '2024-07-16 10:05:51', '', 0, 'https://localhost/mota/?p=86', 2, 'nav_menu_item', '', 0),
(87, 1, '2024-07-16 12:05:51', '2024-07-16 10:05:51', ' ', '', '', 'publish', 'closed', 'closed', '', '87', '', '', '2024-07-16 12:05:51', '2024-07-16 10:05:51', '', 0, 'https://localhost/mota/?p=87', 3, 'nav_menu_item', '', 0),
(88, 1, '2024-07-16 12:05:51', '2024-07-16 10:05:51', ' ', '', '', 'publish', 'closed', 'closed', '', '88', '', '', '2024-07-16 12:05:51', '2024-07-16 10:05:51', '', 0, 'https://localhost/mota/?p=88', 4, 'nav_menu_item', '', 0),
(89, 1, '2024-07-16 12:10:29', '2024-07-16 10:10:29', '<!-- wp:navigation {"ref":13} /-->', 'Accueil', '', 'inherit', 'closed', 'closed', '', '36-autosave-v1', '', '', '2024-07-16 12:10:29', '2024-07-16 10:10:29', '', 36, 'https://localhost/mota/?p=89', 0, 'revision', '', 0),
(91, 1, '2024-08-06 16:09:34', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2024-08-06 16:09:34', '0000-00-00 00:00:00', '', 0, 'https://localhost/mota/?p=91', 0, 'post', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_smush_dir_images`
#

DROP TABLE IF EXISTS `wp_smush_dir_images`;


#
# Table structure of table `wp_smush_dir_images`
#

CREATE TABLE `wp_smush_dir_images` (
  `id` mediumint(9) unsigned NOT NULL AUTO_INCREMENT,
  `path` text NOT NULL,
  `path_hash` char(32) DEFAULT NULL,
  `resize` varchar(55) DEFAULT NULL,
  `lossy` varchar(55) DEFAULT NULL,
  `error` varchar(55) DEFAULT NULL,
  `image_size` int(10) unsigned DEFAULT NULL,
  `orig_size` int(10) unsigned DEFAULT NULL,
  `file_time` int(10) unsigned DEFAULT NULL,
  `last_scan` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `meta` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `path_hash` (`path_hash`),
  KEY `image_size` (`image_size`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_smush_dir_images`
#

#
# End of data contents of table `wp_smush_dir_images`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `term_order` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(15, 4, 0),
(22, 6, 0),
(22, 7, 0),
(22, 8, 0),
(22, 9, 0),
(23, 8, 0),
(23, 10, 0),
(23, 11, 0),
(23, 12, 0),
(23, 13, 0),
(26, 2, 0),
(34, 3, 0),
(35, 3, 0),
(39, 2, 0),
(46, 15, 0),
(46, 18, 0),
(46, 23, 0),
(67, 14, 0),
(67, 18, 0),
(67, 20, 0),
(68, 14, 0),
(68, 18, 0),
(68, 21, 0),
(69, 15, 0),
(69, 18, 0),
(69, 22, 0),
(70, 16, 0),
(70, 19, 0),
(70, 20, 0),
(71, 16, 0),
(71, 19, 0),
(71, 21, 0),
(72, 16, 0),
(72, 19, 0),
(72, 22, 0),
(73, 16, 0),
(73, 18, 0),
(73, 21, 0),
(74, 16, 0),
(74, 18, 0),
(74, 20, 0),
(75, 15, 0),
(75, 19, 0),
(75, 22, 0),
(76, 16, 0),
(76, 18, 0),
(76, 23, 0),
(77, 17, 0),
(77, 18, 0),
(77, 23, 0),
(78, 15, 0),
(78, 18, 0),
(78, 23, 0),
(79, 16, 0),
(79, 19, 0),
(79, 23, 0),
(80, 16, 0),
(80, 19, 0),
(80, 23, 0),
(81, 16, 0),
(81, 19, 0),
(81, 23, 0),
(85, 24, 0),
(86, 24, 0),
(87, 24, 0),
(88, 24, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `taxonomy` varchar(32) NOT NULL DEFAULT '',
  `description` longtext NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT 0,
  `count` bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 2),
(3, 3, 'nav_menu', '', 0, 2),
(4, 4, 'wp_theme', '', 0, 1),
(5, 5, 'wp_template_part_area', '', 0, 0),
(6, 6, 'wpcode_type', '', 0, 1),
(7, 7, 'wpcode_location', '', 0, 1),
(8, 8, 'wpcode_tags', '', 0, 2),
(9, 9, 'wpcode_tags', '', 0, 1),
(10, 10, 'wpcode_type', '', 0, 1),
(11, 11, 'wpcode_location', '', 0, 1),
(12, 12, 'wpcode_tags', '', 0, 1),
(13, 13, 'wpcode_tags', '', 0, 1),
(14, 14, 'categorie', '', 0, 2),
(15, 15, 'categorie', '', 0, 4),
(16, 16, 'categorie', '', 0, 9),
(17, 17, 'categorie', '', 0, 1),
(18, 18, 'format', '', 0, 9),
(19, 19, 'format', '', 0, 7),
(20, 20, 'annee', '', 0, 3),
(21, 21, 'annee', '', 0, 3),
(22, 22, 'annee', '', 0, 3),
(23, 23, 'annee', '', 0, 7),
(24, 24, 'nav_menu', '', 0, 4) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL DEFAULT '',
  `slug` varchar(200) NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT 0,
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Non classé', 'non-classe', 0),
(2, 'Menu principal', 'menu-principal', 0),
(3, 'Menu footer', 'menu-footer', 0),
(4, 'Mota-child', 'mota-child', 0),
(5, 'header', 'header', 0),
(6, 'text', 'text', 0),
(7, 'after_paragraph', 'after_paragraph', 0),
(8, 'sample', 'sample', 0),
(9, 'message', 'message', 0),
(10, 'php', 'php', 0),
(11, 'everywhere', 'everywhere', 0),
(12, 'disable', 'disable', 0),
(13, 'comments', 'comments', 0),
(14, 'Réception', 'reception', 0),
(15, 'Concert', 'concert', 0),
(16, 'Mariage', 'mariage', 0),
(17, 'Télévision', 'television', 0),
(18, 'Paysage', 'paysage', 0),
(19, 'Portrait', 'portrait', 0),
(20, '2019', '2019', 0),
(21, '2020', '2020', 0),
(22, '2021', '2021', 0),
(23, '2022', '2022', 0),
(24, 'liste-categories', 'liste-categories', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT 0,
  `meta_key` varchar(255) DEFAULT NULL,
  `meta_value` longtext DEFAULT NULL,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'sarianyxadmin'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'syntax_highlighting', 'true'),
(7, 1, 'comment_shortcuts', 'false'),
(8, 1, 'admin_color', 'fresh'),
(9, 1, 'use_ssl', '0'),
(10, 1, 'show_admin_bar_front', 'true'),
(11, 1, 'locale', ''),
(12, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(13, 1, 'wp_user_level', '10'),
(14, 1, 'dismissed_wp_pointers', ''),
(15, 1, 'show_welcome_panel', '0'),
(16, 1, 'session_tokens', 'a:1:{s:64:"9849db3f7ea70ca6c58bc80a39937cad1e80d27c7be206d1fea00183d293a594";a:4:{s:10:"expiration";i:1723126171;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:80:"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0";s:5:"login";i:1722953371;}}'),
(17, 1, 'wp_dashboard_quick_press_last_post_id', '91'),
(18, 1, 'community-events-location', 'a:1:{s:2:"ip";s:9:"127.0.0.0";}'),
(19, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(20, 1, 'metaboxhidden_nav-menus', 'a:1:{i:0;s:12:"add-post_tag";}'),
(21, 1, 'nav_menu_recently_edited', '24'),
(22, 1, 'wp_persisted_preferences', 'a:4:{s:14:"core/edit-post";a:3:{s:26:"isComplementaryAreaVisible";b:1;s:12:"welcomeGuide";b:0;s:20:"welcomeGuideTemplate";b:0;}s:4:"core";a:1:{s:10:"openPanels";a:5:{i:0;s:11:"post-status";i:1;s:21:"taxonomy-panel-format";i:2;s:14:"featured-image";i:3;s:20:"taxonomy-panel-annee";i:4;s:24:"taxonomy-panel-categorie";}}s:9:"_modified";s:24:"2024-08-07T10:01:18.639Z";s:14:"core/edit-site";a:3:{s:12:"welcomeGuide";b:0;s:26:"isComplementaryAreaVisible";b:1;s:18:"welcomeGuideStyles";b:0;}}'),
(23, 1, 'wp_user-settings', 'libraryContent=browse'),
(24, 1, 'wp_user-settings-time', '1719924295'),
(25, 1, 'closedpostboxes_photo', 'a:0:{}'),
(26, 1, 'metaboxhidden_photo', 'a:0:{}'),
(27, 1, 'meta-box-order_photo', 'a:4:{s:6:"normal";s:0:"";s:8:"advanced";s:23:"acf-group_6683f395428b1";s:4:"side";s:0:"";s:15:"acf_after_title";s:0:"";}'),
(28, 1, 'manageedit-acf-taxonomycolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(29, 1, 'acf_user_settings', 'a:2:{s:20:"taxonomies-first-run";b:1;s:19:"post-type-first-run";b:1;}'),
(30, 1, 'manageedit-acf-post-typecolumnshidden', 'a:1:{i:0;s:7:"acf-key";}'),
(31, 1, 'closedpostboxes_dashboard', 'a:2:{i:0;s:18:"dashboard_activity";i:1;s:17:"dashboard_primary";}'),
(32, 1, 'metaboxhidden_dashboard', 'a:0:{}'),
(33, 1, 'wp_media_library_mode', 'grid') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) NOT NULL DEFAULT '',
  `user_pass` varchar(255) NOT NULL DEFAULT '',
  `user_nicename` varchar(50) NOT NULL DEFAULT '',
  `user_email` varchar(100) NOT NULL DEFAULT '',
  `user_url` varchar(100) NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT 0,
  `display_name` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_520_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'sarianyxadmin', '$P$BnTRQp9fSkvO6XlKDuxwfEv8leSBAP.', 'sarianyxadmin', 'erchluprev@gmail.com', 'https://localhost/mota', '2024-06-26 09:23:11', '', 0, 'sarianyxadmin') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

